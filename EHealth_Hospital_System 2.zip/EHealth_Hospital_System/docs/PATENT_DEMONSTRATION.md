# Patent Demonstration & Technical Mechanism Specification

> [!NOTE] Academic & Patent Disclosure Notice
> This document describes technical mechanisms implemented in the Apex Care E-Health Management System for research, demonstration, and evaluation purposes. Standard functionality such as web-based appointment booking, role-based login, and invoicing are standard healthcare IT features and are **not** claimed as patentable per se. No patent has been granted, nor is novelty officially established.

---

## 1. Technical Field & Proposed Mechanism

### Title of Proposed Technical Mechanism:
**Cryptographically Bound Electronic Signature and Informed Consent Tracking with Partitioned Multi-Role Transactional Ledger (CV-ESCBA)**

### Problem Statement:
In hospital management systems, patient consent forms (e.g., surgical permissions, clinical data processing agreements, financial liability acknowledgments) are frequently maintained as unverified paper forms or simple database checkboxes. Checkbox consents lack individual biometrics or verifiable proof of assent, while scanned paper consents decouple the patient's signature from the underlying digital billing and prescription records. This causes non-repudiation disputes, unauthorized clinical data inspection, and financial reconciliation discrepancies.

### Technical Solution:
The system implements a tightly coupled, multi-stage electronic consent binding pipeline:

```mermaid
sequenceDiagram
    autonumber
    actor Patient as Patient (Client Device)
    participant Pad as HTML5 Canvas Signature Pad
    participant Controller as SignatureController / PatientService
    participant HashEngine as Cryptographic SHA-256 Engine
    participant DB as Relational Database (Signatures & Consents)
    participant Audit as Immutable Security Audit Log

    Patient->>Pad: Draws handwritten stroke gesture (mouse / capacitive touch)
    Pad->>Pad: Rasterizes strokes to Base64 PNG Data URL
    Patient->>Controller: Submits Consent Form (Type, Title, Text, SignatureDataUrl)
    Controller->>HashEngine: Computes SHA-256 Digest of rasterized stroke bytes
    HashEngine-->>Controller: Returns 64-char Hex Hash (signature_hash)
    Controller->>DB: Stores SignatureRecord (data_url, hash, client_ip, user_agent, timestamp)
    Controller->>DB: Supersedes/Revokes prior version if active (versioning: v1.0 -> v2.0)
    Controller->>DB: Links ConsentRecord to SignatureRecord & Patient MRN
    Controller->>Audit: Emits ELECTRONIC_CONSENT_SIGNED audit record with hash digest
    Audit-->>DB: Commits immutable audit row
    Controller-->>Patient: Confirms legal consent registration with tamper-evident checksum
```

---

## 2. Key Novel Technical Characteristics

1. **Pixel-Level Cryptographic Integrity**:
   - The handwritten signature stroke data URL is converted into a SHA-256 hash. Any byte-level alteration to the signature canvas immediately invalidates the stored checksum.
2. **Dynamic Consent Replacement & Tamper Logging**:
   - When a patient revokes or updates a consent, prior versions are not deleted (`DELETE` is prohibited). Instead, a revocation timestamp and reason are logged with the caller's IP address, preserving the evidentiary chain.
3. **Multi-Role Clinical Partitioning with Transactional Synchronization**:
   - Doctors are physically barred by application-level predicate queries (`!appointment.getDoctor().getId().equals(currentDoctor.getId())`) from viewing unauthorized patient files.
   - When a consultation completes, charges are automatically transferred to billing without exposing doctor diagnosis fields to billing personnel.

---

## 3. Verification Test Cases

The accompanying automated test suite validates these mechanisms:

1. `SignatureServiceTest.testRecordSignatureAndConsent()`:
   - Validates that a 64-character SHA-256 cryptographic digest is generated and bound to the patient consent entity.
2. `SignatureServiceTest.testRejectInvalidSignaturePayload()`:
   - Asserts that tampered or invalid signature payloads lacking valid MIME raster headers are rejected.
3. `SecurityAccessControlTest.testDoctorCannotModifyAnotherDoctorsAppointment()`:
   - Verifies that cross-clinician record manipulation throws `AccessDeniedException`.
4. `AppointmentServiceTest.testBookAppointmentRejectsConflict()`:
   - Verifies that concurrent appointment booking collisions for identical doctor time slots are rejected.
