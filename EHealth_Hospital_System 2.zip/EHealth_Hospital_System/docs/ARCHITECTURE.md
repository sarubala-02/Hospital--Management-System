# E-Health Management System - Technical Architecture

## 1. System Overview

The **Apex Care E-Health Management System** is an enterprise-grade Java web application built on **Java 21**, **Spring Boot 3.3.x**, **Spring Security 6**, **Spring Data JPA**, **Thymeleaf**, and **Bootstrap 5**.

The architecture adheres to clean **Separation of Concerns (SoC)** and follows a strict multi-tiered Model-View-Controller (MVC) paradigm:

```mermaid
graph TD
    Client["Browser / Client Device (Desktop & Mobile)"]
    
    subgraph Presentation_Layer["Presentation Layer (Thymeleaf & Static Assets)"]
        UI["Responsive HTML5 / CSS3 / JavaScript (Bootstrap 5)"]
        SigPad["HTML5 Canvas Signature Engine"]
        PayModal["Sandbox Gateway Modal & Dynamic Slot AJAX"]
    end
    
    subgraph Security_Layer["Security & Access Control Layer (Spring Security 6)"]
        SecFilter["SecurityFilterChain & CustomAuthenticationSuccessHandler"]
        RoleGuard["Role-Based Route Guards (ADMIN, DOCTOR, RECEPTIONIST, BILLING, PATIENT)"]
        MethodSec["Method Security (@PreAuthorize) & CSRF Filter"]
    end
    
    subgraph Controller_Layer["Controller Layer (Spring MVC)"]
        HomeCtrl["HomeController & AuthController"]
        AdminCtrl["AdminController"]
        DoctorCtrl["DoctorController"]
        ReceptCtrl["ReceptionistController"]
        BillingCtrl["BillingController"]
        PatientCtrl["PatientController"]
        PdfCtrl["PdfReportController"]
    end

    subgraph Service_Layer["Service & Business Logic Layer (@Transactional)"]
        ApptService["AppointmentService (Slot Engine & Double-Booking Lock)"]
        ConsService["ConsultationService (Rx & Clinical Partitioning)"]
        BillService["BillingService (Itemized Invoices & Tariff Ledger)"]
        PayService["PaymentService (HMAC Sandbox & Offline Cashier)"]
        SigService["SignatureService (SHA-256 Tamper-Evident Binding)"]
        PdfService["PdfService (OpenPDF Engine)"]
        AuditService["AuditLogService"]
        NotifService["NotificationService"]
    end

    subgraph Data_Access_Layer["Data Access Layer (Spring Data JPA / Hibernate 6)"]
        Repos["Repository Interfaces (JpaRepository)"]
        Hikari["HikariCP Connection Pool"]
    end

    subgraph Persistence_Layer["Database Layer"]
        MySQL[("MySQL 8 RDBMS (UTF-8 MB4)")]
        H2[("H2 In-Memory DB (Fallback / Instant Dev)")]
    end

    Client --> UI
    UI --> SecFilter
    SecFilter --> RoleGuard
    RoleGuard --> Controller_Layer
    Controller_Layer --> Service_Layer
    Service_Layer --> Repos
    Repos --> Hikari
    Hikari --> MySQL
    Hikari --> H2
```

---

## 2. Security & Role Partitioning Matrix

The system enforces strict multi-tenant clinical boundaries:

| Resource / URL Route | Permitted Roles | Clinical Privacy Boundary Enforced |
| :--- | :--- | :--- |
| `/admin/**` | `ROLE_ADMIN` | Full hospital governance; no direct clinical modification. |
| `/doctor/**` | `ROLE_DOCTOR` | **Strict isolation**: Doctors can only view appointments and patients assigned to them. Access to other clinicians' patient records throws `AccessDeniedException`. |
| `/receptionist/**` | `ROLE_RECEPTIONIST` | Search patients, book non-conflicting slots, and check in arrivals. Cannot view doctor diagnostic notes or prescriptions. |
| `/billing/**` | `ROLE_BILLING` | Itemize invoices, add authorized lab fees, record offline cash/card payments. Cannot alter doctor diagnoses or secret fee tariffs. |
| `/patient/**` | `ROLE_PATIENT` | **Self-access only**: Patient can only query and pay their own invoices, view their own prescriptions, and sign their own legal consents. |
| `/invoices/{id}/pdf` | Authorized actors | Verifies caller is either the patient, assigned doctor, billing staff, or admin. |
