# Appointment-to-Billing Workflow & Sequence Diagrams

## 1. End-to-End Clinical Lifecycle Workflow

```mermaid
flowchart TD
    A["Patient Registration / Login"] --> B["Select Department & Doctor"]
    B --> C["Dynamic Slot Query (Check Doctor Availability)"]
    C --> D{"Slot Available?"}
    D -- No --> C
    D -- Yes --> E["Transactional Booking (Unique Slot Lock)"]
    E --> F["Appointment Created (Status: CONFIRMED)"]
    F --> G["Doctor & Patient Receive Automated Notifications"]
    G --> H["Patient Arrives at Clinic"]
    H --> I["Receptionist Check-in Desk (Status: CHECKED_IN)"]
    I --> J["Doctor Outpatient Examination"]
    J --> K["Doctor Enters Diagnosis, Clinical Notes & Prescription Items"]
    K --> L["Doctor Forwards Consultation Fee (Status: COMPLETED)"]
    L --> M["Billing Department Generates Itemized Invoice"]
    M --> N["Add Diagnostic Lab / Ward / Pharmacy Fees + Taxes"]
    N --> O{"Payment Channel Selection"}
    O -- Online --> P["Sandbox Gateway Modal (Test Token Verification)"]
    O -- Offline --> Q["Cash / POS Card Terminal Receipt Issued"]
    P --> R["Server-side HMAC Verification & Balance Settlement"]
    Q --> R
    R --> S["Invoice Marked as PAID (Balance: 0.00)"]
    S --> T["Official PDF Invoice & Payment Receipt Downloaded"]
    T --> U["All Financial & Medical Actions Permanently Audited"]
```

---

## 2. Real-Time Concurrency & Double-Booking Prevention

To prevent double booking when multiple patients or receptionists simultaneously attempt to schedule an appointment for the same doctor at the same hour:

1. **Pre-check Query**: `findConflictingSlot(doctor, appointmentDate, appointmentTime)` filters existing active appointments (excluding cancelled/rejected records).
2. **Database Unique Constraint**: A compound unique constraint on the database enforces physical concurrency protection:
   ```sql
   UNIQUE KEY uq_doctor_slot (doctor_id, appointment_date, appointment_time)
   ```
3. **Transaction Rollback**: Any concurrent thread attempting to insert an identical tuple triggers a `DataIntegrityViolationException`, safely caught and reported as a clear user prompt.
