# Relational Database Schema & Entity Relationship Diagram (ERD)

The E-Health Hospital Management System uses a normalized relational schema (MySQL 8 / H2 compatibility) designed for clinical accuracy, audit accountability, and zero data redundancy.

```mermaid
erDiagram
    users ||--o{ user_roles : has
    roles ||--o{ user_roles : assigned_to
    users ||--o| doctors : links_to
    users ||--o| patients : links_to
    users ||--o{ notifications : receives
    users ||--o{ audit_logs : performs

    departments ||--o{ doctors : employs
    doctors ||--o{ doctor_availability : schedules
    doctors ||--o{ appointments : consults
    doctors ||--o{ consultations : conducts
    doctors ||--o{ prescriptions : writes

    patients ||--o{ appointments : books
    patients ||--o{ consultations : attends
    patients ||--o{ medical_records : owns
    patients ||--o{ prescriptions : receives
    patients ||--o{ invoices : billed_to
    patients ||--o{ signatures : executes
    patients ||--o{ consent_records : grants

    appointments ||--o| consultations : results_in
    appointments ||--o| invoices : billed_via
    consultations ||--o| prescriptions : prescribes
    prescriptions ||--o{ prescription_items : contains

    invoices ||--o{ invoice_items : contains
    invoices ||--o{ payments : receives
    invoices ||--o{ payment_transactions : settles

    signatures ||--o{ consent_records : validates
```

---

## Relational Tables Summary

1. `users`: Core authentication identity, BCrypt password hashes, and active status.
2. `roles`: Role definitions (`ROLE_ADMIN`, `ROLE_DOCTOR`, `ROLE_RECEPTIONIST`, `ROLE_BILLING`, `ROLE_PATIENT`).
3. `user_roles`: Many-to-many join table mapping users to roles.
4. `departments`: Medical specialties, codes, and department chairs.
5. `doctors`: Clinician qualifications, licenses, room numbers, and consultation fees.
6. `patients`: Demographics, Medical Record Number (MRN), blood group, allergies, chronic conditions.
7. `doctor_availability`: Daily hours (start time, end time, slot duration).
8. `appointments`: Unique booking reference, date, time slot, status, and double-booking constraint (`uq_doctor_slot`).
9. `consultations`: Symptoms, diagnosis, clinical notes, follow-up date, consultation fee.
10. `prescriptions`: Electronic prescription header and general advice.
11. `prescription_items`: Medicine name, dosage, frequency, duration, special instructions.
12. `medical_records`: Patient clinical repository (consultation summaries, lab attachments).
13. `invoices`: Unique invoice number, subtotal, tax rate/amount, discount, total, paid amount, balance due, status.
14. `invoice_items`: Description, category (CONSULTATION, LAB, PHARMACY, PROCEDURE, ROOM, MISC), quantity, unit price.
15. `payments`: Payment number, invoice FK, payment method (CASH, CARD_TERMINAL, BANK_TRANSFER, ONLINE_GATEWAY), reference.
16. `payment_transactions`: Gateway order ID, transaction ID, provider, status, server verification log.
17. `signatures`: Patient signature data URL (Base64 PNG) and SHA-256 integrity hash.
18. `consent_records`: Informed consent document title, text, version, revocation tracking.
19. `notifications`: Real-time user alert queue and read/unread status.
20. `audit_logs`: Timestamped audit trail of sensitive patient record views, invoice creations, and authorization events.
21. `hospital_settings`: System configurations, organization name, tax rates, currency code.
