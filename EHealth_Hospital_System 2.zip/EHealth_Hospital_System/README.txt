E-Health Hospital Management System (Java Swing)

RUN ON MAC
1. Extract EHealth_Hospital_System.zip.
2. Open the extracted EHealth_Hospital_System folder.
3. Double-click run.command.
4. If macOS blocks it, open Terminal in this folder and run:
   chmod +x run.command
   ./run.command

REQUIREMENTS
- JDK 8 or newer (both java and javac commands must work).
- No third-party Java libraries required.

MODULES
- Dashboard
- Patients: create, view, update, delete, search, export CSV; duplicate patient checks
- Doctors: create, view, update, delete, search, export CSV; duplicate doctor checks
- Appointments: create, view, update, delete, search, export CSV; duplicate time-slot checks
- Medical Records: create, view, update, delete, search, export CSV; duplicate record checks
- Billing: create, view, update, delete, search, export CSV; automatic total calculation and duplicate bill checks
- Local CSV persistence in hospital_data/

DATA
The app creates hospital_data next to the app and stores CSV files there.
Back up this folder to preserve data.

IMPORTANT
This is a student/demo application, not a production hospital information system.
It has no authentication, encryption, audit logging, backups, or regulatory safeguards.
Do not enter real patient data. The medical records module is only for academic demonstration.
