#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "================================================================="
echo "   APEX CARE E-HEALTH MANAGEMENT SYSTEM - WEB APPLICATION"
echo "   Technology: Java 21, Spring Boot 3, Thymeleaf, Security 6"
echo "================================================================="

# 1. Detect and configure Java Runtime
if [ -z "$JAVA_HOME" ]; then
  if [ -x "/usr/libexec/java_home" ]; then
    DETECTED_JAVA=$(/usr/libexec/java_home 2>/dev/null || true)
    if [ -n "$DETECTED_JAVA" ]; then
      export JAVA_HOME="$DETECTED_JAVA"
    fi
  fi
  if [ -z "$JAVA_HOME" ] && [ -d "/Library/Java/JavaVirtualMachines/jdk-26.jdk/Contents/Home" ]; then
    export JAVA_HOME="/Library/Java/JavaVirtualMachines/jdk-26.jdk/Contents/Home"
  fi
fi

if [ -n "$JAVA_HOME" ]; then
  export PATH="$JAVA_HOME/bin:$PATH"
fi

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java 21+ runtime not found."
  echo "Please install Java JDK from: https://adoptium.net/"
  echo
  read -r -p "Press Enter to exit..."
  exit 1
fi

echo ">> Java detected:"
java -version
echo

# 2. Select Maven executable (system mvn or standalone wrapper)
MAVEN_CMD="./mvnw"
if command -v mvn >/dev/null 2>&1; then
  MAVEN_CMD="mvn"
fi

chmod +x ./mvnw 2>/dev/null || true

echo ">> Launching Spring Boot Web Application in Standalone Mode (H2 DB)..."
echo ">> Portal will be available at: http://localhost:8080"
echo ">> Press Ctrl+C in this terminal window anytime to stop the server."
echo "================================================================="
echo

$MAVEN_CMD spring-boot:run -Dspring-boot.run.profiles=h2
