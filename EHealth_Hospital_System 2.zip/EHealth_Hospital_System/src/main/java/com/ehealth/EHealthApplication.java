package com.ehealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
public class EHealthApplication {

    public static void main(String[] args) {
        SpringApplication.run(EHealthApplication.class, args);
    }
}
