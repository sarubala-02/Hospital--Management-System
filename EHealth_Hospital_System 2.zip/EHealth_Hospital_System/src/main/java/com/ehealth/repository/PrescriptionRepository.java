package com.ehealth.repository;

import com.ehealth.entity.Consultation;
import com.ehealth.entity.Doctor;
import com.ehealth.entity.Patient;
import com.ehealth.entity.Prescription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PrescriptionRepository extends JpaRepository<Prescription, Long> {
    Optional<Prescription> findByConsultation(Consultation consultation);
    Optional<Prescription> findByConsultationId(Long consultationId);
    List<Prescription> findByPatientOrderByCreatedAtDesc(Patient patient);
    List<Prescription> findByDoctorOrderByCreatedAtDesc(Doctor doctor);
}
