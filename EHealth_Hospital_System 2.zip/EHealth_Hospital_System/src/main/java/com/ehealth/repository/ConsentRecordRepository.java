package com.ehealth.repository;

import com.ehealth.entity.ConsentRecord;
import com.ehealth.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ConsentRecordRepository extends JpaRepository<ConsentRecord, Long> {
    List<ConsentRecord> findByPatientOrderBySignedAtDesc(Patient patient);
    Optional<ConsentRecord> findByPatientAndConsentTypeAndRevokedFalse(Patient patient, String consentType);
    List<ConsentRecord> findByPatientIdOrderBySignedAtDesc(Long patientId);
}
