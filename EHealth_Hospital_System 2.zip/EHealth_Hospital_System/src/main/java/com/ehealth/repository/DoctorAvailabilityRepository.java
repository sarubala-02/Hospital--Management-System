package com.ehealth.repository;

import com.ehealth.entity.Doctor;
import com.ehealth.entity.DoctorAvailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability, Long> {
    List<DoctorAvailability> findByDoctorAndActiveTrue(Doctor doctor);
    List<DoctorAvailability> findByDoctorIdAndActiveTrue(Long doctorId);
    Optional<DoctorAvailability> findByDoctorAndDayOfWeekAndActiveTrue(Doctor doctor, DayOfWeek dayOfWeek);
    Optional<DoctorAvailability> findByDoctorIdAndDayOfWeekAndActiveTrue(Long doctorId, DayOfWeek dayOfWeek);
}
