package com.ehealth.repository;

import com.ehealth.entity.Patient;
import com.ehealth.entity.SignatureRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SignatureRepository extends JpaRepository<SignatureRecord, Long> {
    List<SignatureRecord> findByPatientOrderByCreatedAtDesc(Patient patient);
}
