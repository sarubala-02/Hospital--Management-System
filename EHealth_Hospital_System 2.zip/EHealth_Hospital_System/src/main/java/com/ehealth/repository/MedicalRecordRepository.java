package com.ehealth.repository;

import com.ehealth.entity.Doctor;
import com.ehealth.entity.MedicalRecord;
import com.ehealth.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Long> {
    List<MedicalRecord> findByPatientOrderByRecordedAtDesc(Patient patient);
    List<MedicalRecord> findByPatientAndDoctorOrderByRecordedAtDesc(Patient patient, Doctor doctor);
}
