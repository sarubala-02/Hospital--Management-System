package com.ehealth.repository;

import com.ehealth.entity.Appointment;
import com.ehealth.entity.Doctor;
import com.ehealth.entity.Invoice;
import com.ehealth.entity.InvoiceStatus;
import com.ehealth.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    Optional<Invoice> findByInvoiceNumber(String invoiceNumber);

    Optional<Invoice> findByAppointment(Appointment appointment);

    Optional<Invoice> findByAppointmentId(Long appointmentId);

    List<Invoice> findByPatientOrderByCreatedAtDesc(Patient patient);

    List<Invoice> findByDoctorOrderByCreatedAtDesc(Doctor doctor);

    List<Invoice> findByStatusOrderByCreatedAtDesc(InvoiceStatus status);

    List<Invoice> findAllByOrderByCreatedAtDesc();

    long countByStatus(InvoiceStatus status);

    @Query("SELECT COALESCE(SUM(i.totalAmount), 0) FROM Invoice i WHERE i.status != 'CANCELLED'")
    BigDecimal sumTotalBilled();

    @Query("SELECT COALESCE(SUM(i.paidAmount), 0) FROM Invoice i")
    BigDecimal sumTotalCollected();

    @Query("SELECT COALESCE(SUM(i.balanceAmount), 0) FROM Invoice i WHERE i.status IN ('UNPAID', 'PARTIALLY_PAID')")
    BigDecimal sumTotalOutstanding();
}
