package com.ehealth.repository;

import com.ehealth.entity.Invoice;
import com.ehealth.entity.Patient;
import com.ehealth.entity.PaymentTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {
    Optional<PaymentTransaction> findByTransactionId(String transactionId);
    Optional<PaymentTransaction> findByGatewayOrderId(String gatewayOrderId);
    List<PaymentTransaction> findByInvoice(Invoice invoice);
    List<PaymentTransaction> findByPatientOrderByCreatedAtDesc(Patient patient);
}
