package com.ehealth.repository;

import com.ehealth.entity.Appointment;
import com.ehealth.entity.Consultation;
import com.ehealth.entity.Doctor;
import com.ehealth.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ConsultationRepository extends JpaRepository<Consultation, Long> {
    Optional<Consultation> findByAppointment(Appointment appointment);
    Optional<Consultation> findByAppointmentId(Long appointmentId);
    List<Consultation> findByPatientOrderByCreatedAtDesc(Patient patient);
    List<Consultation> findByDoctorOrderByCreatedAtDesc(Doctor doctor);
}
