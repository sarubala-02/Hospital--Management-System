package com.ehealth.repository;

import com.ehealth.entity.Department;
import com.ehealth.entity.Doctor;
import com.ehealth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    Optional<Doctor> findByUser(User user);
    Optional<Doctor> findByUserId(Long userId);
    List<Doctor> findAllByAvailableTrue();
    List<Doctor> findByDepartmentAndAvailableTrue(Department department);
    List<Doctor> findByDepartmentIdAndAvailableTrue(Long departmentId);
    Optional<Doctor> findByLicenseNumber(String licenseNumber);
}
