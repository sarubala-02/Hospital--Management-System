package com.ehealth.dto;

import jakarta.validation.constraints.NotBlank;

public class SignatureDto {

    @NotBlank(message = "Signature image data is required")
    private String signatureDataUrl;

    @NotBlank(message = "Consent title is required")
    private String consentTitle;

    @NotBlank(message = "Consent type is required")
    private String consentType;

    @NotBlank(message = "Consent text is required")
    private String consentText;

    public SignatureDto() {}

    public String getSignatureDataUrl() {
        return signatureDataUrl;
    }

    public void setSignatureDataUrl(String signatureDataUrl) {
        this.signatureDataUrl = signatureDataUrl;
    }

    public String getConsentTitle() {
        return consentTitle;
    }

    public void setConsentTitle(String consentTitle) {
        this.consentTitle = consentTitle;
    }

    public String getConsentType() {
        return consentType;
    }

    public void setConsentType(String consentType) {
        this.consentType = consentType;
    }

    public String getConsentText() {
        return consentText;
    }

    public void setConsentText(String consentText) {
        this.consentText = consentText;
    }
}
