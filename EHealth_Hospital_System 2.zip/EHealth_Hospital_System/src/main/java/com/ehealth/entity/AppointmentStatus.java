package com.ehealth.entity;

public enum AppointmentStatus {
    PENDING,
    CONFIRMED,
    CHECKED_IN,
    IN_CONSULTATION,
    COMPLETED,
    CANCELLED,
    REJECTED
}
