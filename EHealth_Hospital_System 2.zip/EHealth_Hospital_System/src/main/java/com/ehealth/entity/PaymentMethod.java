package com.ehealth.entity;

public enum PaymentMethod {
    CASH,
    CARD_TERMINAL,
    BANK_TRANSFER,
    ONLINE_GATEWAY
}
