package com.ehealth.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "consent_records")
public class ConsentRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "signature_id", nullable = false)
    private SignatureRecord signature;

    @Column(name = "consent_title", nullable = false, length = 200)
    private String consentTitle;

    @Column(name = "consent_type", nullable = false, length = 100)
    private String consentType; // GENERAL_TREATMENT, DATA_SHARING, SURGERY, BILLING_AGREEMENT

    @Column(name = "consent_version", nullable = false, length = 20)
    private String consentVersion = "1.0";

    @Lob
    @Column(name = "consent_text", nullable = false, columnDefinition = "LONGTEXT")
    private String consentText;

    @Column(name = "is_revoked", nullable = false)
    private boolean revoked = false;

    @Column(name = "revocation_reason", columnDefinition = "TEXT")
    private String revocationReason;

    @Column(name = "signed_at", updatable = false)
    private LocalDateTime signedAt = LocalDateTime.now();

    @Column(name = "revoked_at")
    private LocalDateTime revokedAt;

    public ConsentRecord() {}

    public ConsentRecord(Patient patient, SignatureRecord signature, String consentTitle,
                         String consentType, String consentVersion, String consentText) {
        this.patient = patient;
        this.signature = signature;
        this.consentTitle = consentTitle;
        this.consentType = consentType;
        this.consentVersion = consentVersion;
        this.consentText = consentText;
        this.revoked = false;
        this.signedAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public SignatureRecord getSignature() {
        return signature;
    }

    public void setSignature(SignatureRecord signature) {
        this.signature = signature;
    }

    public String getConsentTitle() {
        return consentTitle;
    }

    public void setConsentTitle(String consentTitle) {
        this.consentTitle = consentTitle;
    }

    public String getConsentType() {
        return consentType;
    }

    public void setConsentType(String consentType) {
        this.consentType = consentType;
    }

    public String getConsentVersion() {
        return consentVersion;
    }

    public void setConsentVersion(String consentVersion) {
        this.consentVersion = consentVersion;
    }

    public String getConsentText() {
        return consentText;
    }

    public void setConsentText(String consentText) {
        this.consentText = consentText;
    }

    public boolean isRevoked() {
        return revoked;
    }

    public void setRevoked(boolean revoked) {
        this.revoked = revoked;
    }

    public String getRevocationReason() {
        return revocationReason;
    }

    public void setRevocationReason(String revocationReason) {
        this.revocationReason = revocationReason;
    }

    public LocalDateTime getSignedAt() {
        return signedAt;
    }

    public void setSignedAt(LocalDateTime signedAt) {
        this.signedAt = signedAt;
    }

    public LocalDateTime getRevokedAt() {
        return revokedAt;
    }

    public void setRevokedAt(LocalDateTime revokedAt) {
        this.revokedAt = revokedAt;
    }
}
