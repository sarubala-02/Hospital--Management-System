package com.ehealth.entity;

public enum InvoiceStatus {
    UNPAID,
    PARTIALLY_PAID,
    PAID,
    REFUNDED,
    CANCELLED
}
