package com.ehealth.entity;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_DOCTOR,
    ROLE_RECEPTIONIST,
    ROLE_BILLING,
    ROLE_PATIENT
}
