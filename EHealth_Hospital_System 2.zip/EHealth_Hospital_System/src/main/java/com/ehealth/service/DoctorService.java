package com.ehealth.service;

import com.ehealth.entity.Department;
import com.ehealth.entity.Doctor;
import com.ehealth.entity.DoctorAvailability;
import com.ehealth.entity.User;
import com.ehealth.repository.DepartmentRepository;
import com.ehealth.repository.DoctorAvailabilityRepository;
import com.ehealth.repository.DoctorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final AuditLogService auditLogService;

    public DoctorService(DoctorRepository doctorRepository, DepartmentRepository departmentRepository,
                         DoctorAvailabilityRepository availabilityRepository, AuditLogService auditLogService) {
        this.doctorRepository = doctorRepository;
        this.departmentRepository = departmentRepository;
        this.availabilityRepository = availabilityRepository;
        this.auditLogService = auditLogService;
    }

    @Transactional(readOnly = true)
    public List<Doctor> findAllAvailableDoctors() {
        return doctorRepository.findAllByAvailableTrue();
    }

    @Transactional(readOnly = true)
    public List<Doctor> findAllDoctors() {
        return doctorRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Doctor> findDoctorsByDepartment(Long departmentId) {
        return doctorRepository.findByDepartmentIdAndAvailableTrue(departmentId);
    }

    @Transactional(readOnly = true)
    public Optional<Doctor> findById(Long id) {
        return doctorRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<Doctor> findByUser(User user) {
        return doctorRepository.findByUser(user);
    }

    @Transactional(readOnly = true)
    public Optional<Doctor> findByUserId(Long userId) {
        return doctorRepository.findByUserId(userId);
    }

    @Transactional
    public Doctor updateDoctorProfile(Long doctorId, String specialization, String qualification,
                                      BigDecimal fee, String roomNumber, boolean available) {
        Doctor doc = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new IllegalArgumentException("Doctor not found: " + doctorId));
        doc.setSpecialization(specialization);
        doc.setQualification(qualification);
        if (fee != null) {
            doc.setConsultationFee(fee);
        }
        doc.setRoomNumber(roomNumber);
        doc.setAvailable(available);
        Doctor updated = doctorRepository.save(doc);

        auditLogService.log("UPDATE_DOCTOR_PROFILE", "Doctor", doctorId.toString(),
                "Updated doctor profile and consultation fee to: " + fee, null);

        return updated;
    }

    @Transactional(readOnly = true)
    public List<DoctorAvailability> getDoctorSchedule(Doctor doctor) {
        return availabilityRepository.findByDoctorAndActiveTrue(doctor);
    }

    @Transactional
    public void saveDoctorSchedule(Doctor doctor, DayOfWeek dayOfWeek, LocalTime start, LocalTime end, int slotDuration) {
        DoctorAvailability availability = availabilityRepository
                .findByDoctorAndDayOfWeekAndActiveTrue(doctor, dayOfWeek)
                .orElse(new DoctorAvailability(doctor, dayOfWeek, start, end, slotDuration));

        availability.setStartTime(start);
        availability.setEndTime(end);
        availability.setSlotDurationMinutes(slotDuration);
        availability.setActive(true);
        availabilityRepository.save(availability);

        auditLogService.log("UPDATE_DOCTOR_SCHEDULE", "DoctorAvailability", doctor.getId().toString(),
                "Updated availability for " + dayOfWeek + " (" + start + " to " + end + ")", null);
    }

    @Transactional(readOnly = true)
    public List<Department> findAllActiveDepartments() {
        return departmentRepository.findAllByActiveTrue();
    }

    @Transactional(readOnly = true)
    public Optional<Department> findDepartmentById(Long id) {
        return departmentRepository.findById(id);
    }
}
