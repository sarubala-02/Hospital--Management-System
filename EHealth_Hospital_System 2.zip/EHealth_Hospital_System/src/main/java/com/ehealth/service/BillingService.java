package com.ehealth.service;

import com.ehealth.dto.InvoiceCreateDto;
import com.ehealth.entity.*;
import com.ehealth.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Year;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class BillingService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceItemRepository invoiceItemRepository;
    private final AppointmentRepository appointmentRepository;
    private final ConsultationRepository consultationRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final HospitalSettingService settingService;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;

    public BillingService(InvoiceRepository invoiceRepository,
                          InvoiceItemRepository invoiceItemRepository,
                          AppointmentRepository appointmentRepository,
                          ConsultationRepository consultationRepository,
                          PatientRepository patientRepository,
                          DoctorRepository doctorRepository,
                          HospitalSettingService settingService,
                          AuditLogService auditLogService,
                          NotificationService notificationService) {
        this.invoiceRepository = invoiceRepository;
        this.invoiceItemRepository = invoiceItemRepository;
        this.appointmentRepository = appointmentRepository;
        this.consultationRepository = consultationRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.settingService = settingService;
        this.auditLogService = auditLogService;
        this.notificationService = notificationService;
    }

    @Transactional
    public Invoice generateInvoiceFromAppointment(Long appointmentId, User billingStaff) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found: " + appointmentId));

        // Check if invoice already exists for this appointment
        Optional<Invoice> existing = invoiceRepository.findByAppointment(appointment);
        if (existing.isPresent()) {
            return existing.get();
        }

        Consultation consultation = consultationRepository.findByAppointment(appointment).orElse(null);

        String invoiceNum = generateInvoiceNumber();
        LocalDate dueDate = LocalDate.now().plusDays(7);

        Invoice invoice = new Invoice(
                invoiceNum,
                appointment.getPatient(),
                appointment,
                appointment.getDoctor(),
                dueDate
        );
        invoice.setTaxRate(settingService.getTaxRate());
        invoice.setCreatedByUser(billingStaff);

        // Add Consultation fee item
        BigDecimal consultationFee = (consultation != null && consultation.getConsultationFee() != null)
                ? consultation.getConsultationFee()
                : appointment.getDoctor().getConsultationFee();

        InvoiceItem feeItem = new InvoiceItem(
                "Doctor Consultation Fee - " + appointment.getDoctor().getUser().getFullName() + " (" + appointment.getDoctor().getSpecialization() + ")",
                "CONSULTATION",
                1,
                consultationFee
        );
        invoice.addItem(feeItem);

        Invoice saved = invoiceRepository.save(invoice);

        auditLogService.log("GENERATE_INVOICE", "Invoice", saved.getId().toString(),
                "Generated invoice " + invoiceNum + " for appointment " + appointment.getAppointmentNumber() +
                        ", total: " + saved.getTotalAmount(), null);

        notificationService.sendNotification(appointment.getPatient().getUser(), "New Invoice Generated",
                "Invoice " + invoiceNum + " for amount " + settingService.getCurrency() + " " + saved.getTotalAmount() +
                        " has been generated.", "BILLING", "/patient/invoices/" + saved.getId());

        return saved;
    }

    @Transactional
    public Invoice createCustomInvoice(InvoiceCreateDto dto, User billingStaff) {
        Patient patient = patientRepository.findById(dto.getPatientId())
                .orElseThrow(() -> new IllegalArgumentException("Patient not found: " + dto.getPatientId()));

        Doctor doctor = null;
        if (dto.getDoctorId() != null) {
            doctor = doctorRepository.findById(dto.getDoctorId()).orElse(null);
        }

        Appointment appointment = null;
        if (dto.getAppointmentId() != null) {
            appointment = appointmentRepository.findById(dto.getAppointmentId()).orElse(null);
        }

        String invoiceNum = generateInvoiceNumber();
        LocalDate due = dto.getDueDate() != null ? dto.getDueDate() : LocalDate.now().plusDays(7);

        Invoice invoice = new Invoice(invoiceNum, patient, appointment, doctor, due);
        invoice.setTaxRate(settingService.getTaxRate());
        invoice.setDiscountAmount(dto.getDiscountAmount() != null ? dto.getDiscountAmount() : BigDecimal.ZERO);
        invoice.setNotes(dto.getNotes());
        invoice.setCreatedByUser(billingStaff);

        if (dto.getItems() != null) {
            for (InvoiceCreateDto.InvoiceItemDto itemDto : dto.getItems()) {
                if (itemDto.getDescription() != null && !itemDto.getDescription().trim().isEmpty()) {
                    InvoiceItem item = new InvoiceItem(
                            itemDto.getDescription(),
                            itemDto.getCategory(),
                            itemDto.getQuantity() > 0 ? itemDto.getQuantity() : 1,
                            itemDto.getUnitPrice() != null ? itemDto.getUnitPrice() : BigDecimal.ZERO
                    );
                    invoice.addItem(item);
                }
            }
        }

        Invoice saved = invoiceRepository.save(invoice);

        auditLogService.log("CREATE_MANUAL_INVOICE", "Invoice", saved.getId().toString(),
                "Staff created invoice " + invoiceNum + " with total: " + saved.getTotalAmount(), null);

        notificationService.sendNotification(patient.getUser(), "New Hospital Invoice",
                "Invoice " + invoiceNum + " of " + settingService.getCurrency() + " " + saved.getTotalAmount() + " is ready for review/payment.",
                "BILLING", "/patient/invoices/" + saved.getId());

        return saved;
    }

    @Transactional
    public Invoice addItemToInvoice(Long invoiceId, String description, String category, int quantity, BigDecimal unitPrice) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + invoiceId));

        InvoiceItem item = new InvoiceItem(description, category, quantity, unitPrice);
        invoice.addItem(item);
        Invoice saved = invoiceRepository.save(invoice);

        auditLogService.log("ADD_INVOICE_ITEM", "Invoice", invoiceId.toString(),
                "Added item: " + description + " (x" + quantity + " @ " + unitPrice + ")", null);

        return saved;
    }

    @Transactional(readOnly = true)
    public Optional<Invoice> findById(Long id) {
        return invoiceRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<Invoice> findByInvoiceNumber(String invoiceNumber) {
        return invoiceRepository.findByInvoiceNumber(invoiceNumber);
    }

    @Transactional(readOnly = true)
    public Optional<Invoice> findByAppointmentId(Long appointmentId) {
        return invoiceRepository.findByAppointmentId(appointmentId);
    }

    @Transactional(readOnly = true)
    public List<Invoice> findByPatient(Patient patient) {
        return invoiceRepository.findByPatientOrderByCreatedAtDesc(patient);
    }

    @Transactional(readOnly = true)
    public List<Invoice> findByDoctor(Doctor doctor) {
        return invoiceRepository.findByDoctorOrderByCreatedAtDesc(doctor);
    }

    @Transactional(readOnly = true)
    public List<Invoice> findAllInvoices() {
        return invoiceRepository.findAllByOrderByCreatedAtDesc();
    }

    @Transactional(readOnly = true)
    public List<Invoice> findByStatus(InvoiceStatus status) {
        return invoiceRepository.findByStatusOrderByCreatedAtDesc(status);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getFinancialSummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("totalBilled", invoiceRepository.sumTotalBilled());
        summary.put("totalCollected", invoiceRepository.sumTotalCollected());
        summary.put("totalOutstanding", invoiceRepository.sumTotalOutstanding());
        summary.put("unpaidCount", invoiceRepository.countByStatus(InvoiceStatus.UNPAID));
        summary.put("partiallyPaidCount", invoiceRepository.countByStatus(InvoiceStatus.PARTIALLY_PAID));
        summary.put("paidCount", invoiceRepository.countByStatus(InvoiceStatus.PAID));
        return summary;
    }

    private String generateInvoiceNumber() {
        String year = String.valueOf(Year.now().getValue());
        int random = 10000 + (int) (Math.random() * 90000);
        return "INV-" + year + "-" + random;
    }
}
