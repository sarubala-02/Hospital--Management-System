package com.ehealth.service;

import com.ehealth.entity.Invoice;
import com.ehealth.entity.InvoiceItem;
import com.ehealth.entity.Payment;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

@Service
public class PdfService {

    private final HospitalSettingService settingService;

    public PdfService(HospitalSettingService settingService) {
        this.settingService = settingService;
    }

    public byte[] generateInvoicePdf(Invoice invoice) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4, 36, 36, 40, 40);

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Colors
            Color primaryBlue = new Color(24, 76, 120);
            Color darkGray = new Color(50, 50, 50);
            Color lightGray = new Color(240, 244, 248);

            // Fonts
            Font hospitalTitleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, primaryBlue);
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, Color.WHITE);
            Font boldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, darkGray);
            Font regularFont = FontFactory.getFont(FontFactory.HELVETICA, 10, darkGray);
            Font smallFont = FontFactory.getFont(FontFactory.HELVETICA, 8, Color.GRAY);

            // Hospital Header
            Paragraph hospitalName = new Paragraph(settingService.getHospitalName(), hospitalTitleFont);
            hospitalName.setAlignment(Element.ALIGN_CENTER);
            document.add(hospitalName);

            Paragraph hospitalSub = new Paragraph("Excellence in Healthcare & Clinical Research | NABH Accredited", smallFont);
            hospitalSub.setAlignment(Element.ALIGN_CENTER);
            hospitalSub.setSpacingAfter(15);
            document.add(hospitalSub);

            // Invoice Title Banner
            PdfPTable banner = new PdfPTable(2);
            banner.setWidthPercentage(100);
            banner.setWidths(new float[]{60, 40});

            PdfPCell c1 = new PdfPCell(new Phrase("TAX INVOICE / BILL OF SUPPLY", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, primaryBlue)));
            c1.setBorder(Rectangle.NO_BORDER);
            banner.addCell(c1);

            PdfPCell c2 = new PdfPCell(new Phrase("Invoice #: " + invoice.getInvoiceNumber(), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11, darkGray)));
            c2.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c2.setBorder(Rectangle.NO_BORDER);
            banner.addCell(c2);

            document.add(banner);

            Paragraph separator = new Paragraph(" ");
            separator.setSpacingAfter(5);
            document.add(separator);

            // Metadata Table (Patient & Invoice Details)
            PdfPTable metaTable = new PdfPTable(2);
            metaTable.setWidthPercentage(100);
            metaTable.setWidths(new float[]{50, 50});

            // Left: Patient Details
            PdfPCell patientCell = new PdfPCell();
            patientCell.setBorder(Rectangle.BOX);
            patientCell.setPadding(8);
            patientCell.setBackgroundColor(lightGray);
            patientCell.addElement(new Paragraph("PATIENT DETAILS", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, primaryBlue)));
            patientCell.addElement(new Paragraph("Name: " + invoice.getPatient().getUser().getFullName(), boldFont));
            patientCell.addElement(new Paragraph("MRN: " + invoice.getPatient().getMedicalRecordNumber(), regularFont));
            patientCell.addElement(new Paragraph("Phone: " + invoice.getPatient().getUser().getPhone(), regularFont));
            patientCell.addElement(new Paragraph("Email: " + invoice.getPatient().getUser().getEmail(), regularFont));
            metaTable.addCell(patientCell);

            // Right: Invoice & Doctor Info
            PdfPCell infoCell = new PdfPCell();
            infoCell.setBorder(Rectangle.BOX);
            infoCell.setPadding(8);
            infoCell.setBackgroundColor(lightGray);
            infoCell.addElement(new Paragraph("BILLING DETAILS", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, primaryBlue)));
            infoCell.addElement(new Paragraph("Date: " + invoice.getCreatedAt().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm")), regularFont));
            if (invoice.getDueDate() != null) {
                infoCell.addElement(new Paragraph("Due Date: " + invoice.getDueDate().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")), regularFont));
            }
            if (invoice.getDoctor() != null) {
                infoCell.addElement(new Paragraph("Doctor: " + invoice.getDoctor().getUser().getFullName(), regularFont));
                infoCell.addElement(new Paragraph("Department: " + invoice.getDoctor().getDepartment().getName(), regularFont));
            }
            infoCell.addElement(new Paragraph("Status: " + invoice.getStatus().name(), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10,
                    invoice.getStatus() == com.ehealth.entity.InvoiceStatus.PAID ? new Color(0, 150, 0) : Color.RED)));
            metaTable.addCell(infoCell);

            document.add(metaTable);
            document.add(new Paragraph(" "));

            // Line Items Table
            PdfPTable itemsTable = new PdfPTable(5);
            itemsTable.setWidthPercentage(100);
            itemsTable.setWidths(new float[]{10, 45, 15, 15, 15});

            String[] headers = {"#", "Description / Service", "Category", "Qty", "Amount (" + settingService.getCurrency() + ")"};
            for (String h : headers) {
                PdfPCell th = new PdfPCell(new Phrase(h, headerFont));
                th.setBackgroundColor(primaryBlue);
                th.setPadding(6);
                th.setHorizontalAlignment(Element.ALIGN_CENTER);
                itemsTable.addCell(th);
            }

            int count = 1;
            for (InvoiceItem item : invoice.getItems()) {
                PdfPCell num = new PdfPCell(new Phrase(String.valueOf(count++), regularFont));
                num.setHorizontalAlignment(Element.ALIGN_CENTER);
                itemsTable.addCell(num);

                PdfPCell desc = new PdfPCell(new Phrase(item.getDescription(), regularFont));
                itemsTable.addCell(desc);

                PdfPCell cat = new PdfPCell(new Phrase(item.getCategory(), smallFont));
                itemsTable.addCell(cat);

                PdfPCell qty = new PdfPCell(new Phrase(String.valueOf(item.getQuantity()), regularFont));
                qty.setHorizontalAlignment(Element.ALIGN_CENTER);
                itemsTable.addCell(qty);

                PdfPCell tot = new PdfPCell(new Phrase(item.getTotalPrice().toString(), regularFont));
                tot.setHorizontalAlignment(Element.ALIGN_RIGHT);
                itemsTable.addCell(tot);
            }

            document.add(itemsTable);
            document.add(new Paragraph(" "));

            // Totals Summary Table
            PdfPTable totalsTable = new PdfPTable(2);
            totalsTable.setWidthPercentage(45);
            totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);

            addTotalRow(totalsTable, "Subtotal:", invoice.getSubtotal().toString(), regularFont);
            if (invoice.getDiscountAmount().compareTo(BigDecimal.ZERO) > 0) {
                addTotalRow(totalsTable, "Discount:", "-" + invoice.getDiscountAmount().toString(), regularFont);
            }
            addTotalRow(totalsTable, "Tax (GST 5%):", invoice.getTaxAmount().toString(), regularFont);
            addTotalRow(totalsTable, "Grand Total:", settingService.getCurrency() + " " + invoice.getTotalAmount().toString(), boldFont);
            addTotalRow(totalsTable, "Amount Paid:", settingService.getCurrency() + " " + invoice.getPaidAmount().toString(), regularFont);
            addTotalRow(totalsTable, "Balance Due:", settingService.getCurrency() + " " + invoice.getBalanceAmount().toString(),
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11, primaryBlue));

            document.add(totalsTable);

            // Footer & Instructions
            Paragraph notes = new Paragraph();
            notes.setSpacingBefore(20);
            notes.add(new Paragraph("Terms & Instructions:", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, darkGray)));
            notes.add(new Paragraph("1. Payment can be settled online via the Patient Portal or offline at the hospital billing desk.\n" +
                    "2. This document is a computer-generated tax invoice and requires no physical seal.\n" +
                    "3. For billing inquiries, contact billing@apexcare-ehealth.org or call +91 (80) 4567-8900.", smallFont));
            document.add(notes);

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("Error generating PDF invoice", e);
        }

        return out.toByteArray();
    }

    public byte[] generateReceiptPdf(Payment payment) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A5.rotate(), 30, 30, 30, 30);

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            Color primaryBlue = new Color(24, 76, 120);
            Color darkGray = new Color(50, 50, 50);

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, primaryBlue);
            Font boldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, darkGray);
            Font regularFont = FontFactory.getFont(FontFactory.HELVETICA, 9, darkGray);

            Paragraph hospital = new Paragraph(settingService.getHospitalName(), titleFont);
            hospital.setAlignment(Element.ALIGN_CENTER);
            document.add(hospital);

            Paragraph receiptTitle = new Paragraph("OFFICIAL PAYMENT RECEIPT", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, darkGray));
            receiptTitle.setAlignment(Element.ALIGN_CENTER);
            receiptTitle.setSpacingAfter(10);
            document.add(receiptTitle);

            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{40, 60});

            addReceiptRow(table, "Receipt Number:", payment.getPaymentNumber(), boldFont);
            addReceiptRow(table, "Invoice Reference:", payment.getInvoice().getInvoiceNumber(), regularFont);
            addReceiptRow(table, "Payment Date:", payment.getPaymentDate().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm")), regularFont);
            addReceiptRow(table, "Patient Name:", payment.getInvoice().getPatient().getUser().getFullName(), regularFont);
            addReceiptRow(table, "Patient MRN:", payment.getInvoice().getPatient().getMedicalRecordNumber(), regularFont);
            addReceiptRow(table, "Payment Method:", payment.getPaymentMethod().name(), regularFont);
            addReceiptRow(table, "Transaction Ref:", payment.getTransactionReference(), regularFont);
            addReceiptRow(table, "Amount Paid:", settingService.getCurrency() + " " + payment.getAmount().toString(),
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, primaryBlue));
            addReceiptRow(table, "Payment Status:", payment.getPaymentStatus().name(), boldFont);

            document.add(table);

            Paragraph footer = new Paragraph("\nReceived with thanks. Apex Care Hospital Accounts Department.", regularFont);
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("Error generating PDF receipt", e);
        }

        return out.toByteArray();
    }

    private void addTotalRow(PdfPTable table, String label, String value, Font font) {
        PdfPCell c1 = new PdfPCell(new Phrase(label, font));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
        table.addCell(c1);

        PdfPCell c2 = new PdfPCell(new Phrase(value, font));
        c2.setBorder(Rectangle.NO_BORDER);
        c2.setHorizontalAlignment(Element.ALIGN_RIGHT);
        table.addCell(c2);
    }

    private void addReceiptRow(PdfPTable table, String label, String value, Font font) {
        PdfPCell c1 = new PdfPCell(new Phrase(label, font));
        c1.setPadding(4);
        table.addCell(c1);

        PdfPCell c2 = new PdfPCell(new Phrase(value, font));
        c2.setPadding(4);
        table.addCell(c2);
    }
}
