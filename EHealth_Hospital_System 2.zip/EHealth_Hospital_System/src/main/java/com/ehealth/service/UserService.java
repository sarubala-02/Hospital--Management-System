package com.ehealth.service;

import com.ehealth.dto.StaffRegistrationDto;
import com.ehealth.entity.*;
import com.ehealth.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    public UserService(UserRepository userRepository, RoleRepository roleRepository,
                       DoctorRepository doctorRepository, DepartmentRepository departmentRepository,
                       PasswordEncoder passwordEncoder, AuditLogService auditLogService) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.doctorRepository = doctorRepository;
        this.departmentRepository = departmentRepository;
        this.passwordEncoder = passwordEncoder;
        this.auditLogService = auditLogService;
    }

    @Transactional(readOnly = true)
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Transactional(readOnly = true)
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    @Transactional
    public User registerStaff(StaffRegistrationDto dto) {
        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("Username already exists: " + dto.getUsername());
        }
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already registered: " + dto.getEmail());
        }

        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setFullName(dto.getFullName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setActive(true);

        Role role = roleRepository.findByName(dto.getRole())
                .orElseThrow(() -> new IllegalStateException("Role not configured: " + dto.getRole()));
        user.getRoles().add(role);

        User savedUser = userRepository.save(user);

        // If registering a Doctor, also create Doctor entity profile
        if (dto.getRole() == RoleName.ROLE_DOCTOR) {
            Department dept = departmentRepository.findById(dto.getDepartmentId())
                    .orElseThrow(() -> new IllegalArgumentException("Department not found"));
            Doctor doctor = new Doctor(
                    savedUser,
                    dept,
                    dto.getSpecialization(),
                    dto.getQualification(),
                    dto.getLicenseNumber(),
                    dto.getExperienceYears(),
                    dto.getConsultationFee(),
                    dto.getRoomNumber()
            );
            doctorRepository.save(doctor);
        }

        auditLogService.log("CREATE_STAFF_USER", "User", savedUser.getId().toString(),
                "Registered staff user: " + savedUser.getUsername() + " with role: " + dto.getRole(), null);

        return savedUser;
    }

    @Transactional
    public void toggleUserActive(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        user.setActive(!user.isActive());
        userRepository.save(user);
        auditLogService.log("TOGGLE_USER_STATUS", "User", userId.toString(),
                "Changed active status to " + user.isActive() + " for " + user.getUsername(), null);
    }
}
