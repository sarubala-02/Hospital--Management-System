package com.ehealth.service;

import com.ehealth.entity.AuditLog;
import com.ehealth.repository.AuditLogRepository;
import com.ehealth.security.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @Transactional
    public void log(String action, String entityName, String entityId, String details, String ipAddress) {
        String username = SecurityUtils.getCurrentUsername();
        String role = SecurityUtils.getCurrentUserDetails()
                .map(u -> u.getAuthorities().toString())
                .orElse("ROLE_ANONYMOUS");

        AuditLog log = new AuditLog(username, role, action, entityName, entityId, details, ipAddress);
        auditLogRepository.save(log);
    }

    @Transactional(readOnly = true)
    public List<AuditLog> getRecentLogs() {
        return auditLogRepository.findTop100ByOrderByTimestampDesc();
    }

    @Transactional(readOnly = true)
    public List<AuditLog> getAllLogs() {
        return auditLogRepository.findAllByOrderByTimestampDesc();
    }
}
