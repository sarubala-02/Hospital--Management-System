package com.ehealth.service;

import com.ehealth.dto.AppointmentBookingDto;
import com.ehealth.entity.*;
import com.ehealth.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final DepartmentRepository departmentRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;

    public AppointmentService(AppointmentRepository appointmentRepository, DoctorRepository doctorRepository,
                              PatientRepository patientRepository, DepartmentRepository departmentRepository,
                              DoctorAvailabilityRepository availabilityRepository,
                              NotificationService notificationService, AuditLogService auditLogService) {
        this.appointmentRepository = appointmentRepository;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
        this.departmentRepository = departmentRepository;
        this.availabilityRepository = availabilityRepository;
        this.notificationService = notificationService;
        this.auditLogService = auditLogService;
    }

    @Transactional
    public Appointment bookAppointment(Patient patient, AppointmentBookingDto dto) {
        Doctor doctor = doctorRepository.findById(dto.getDoctorId())
                .orElseThrow(() -> new IllegalArgumentException("Doctor not found: " + dto.getDoctorId()));

        Department department = departmentRepository.findById(dto.getDepartmentId())
                .orElseThrow(() -> new IllegalArgumentException("Department not found: " + dto.getDepartmentId()));

        // Double Booking Conflict Check
        Optional<Appointment> conflict = appointmentRepository.findConflictingSlot(
                doctor, dto.getAppointmentDate(), dto.getAppointmentTime()
        );
        if (conflict.isPresent()) {
            throw new IllegalStateException("Selected time slot " + dto.getAppointmentTime() +
                    " on " + dto.getAppointmentDate() + " is already booked for Dr. " + doctor.getUser().getFullName());
        }

        String aptNumber = generateAppointmentNumber();

        Appointment appointment = new Appointment(
                aptNumber,
                patient,
                doctor,
                department,
                dto.getAppointmentDate(),
                dto.getAppointmentTime(),
                dto.getReasonForVisit()
        );
        appointment.setStatus(AppointmentStatus.CONFIRMED);

        Appointment saved = appointmentRepository.save(appointment);

        auditLogService.log("BOOK_APPOINTMENT", "Appointment", saved.getId().toString(),
                "Booked appointment " + aptNumber + " for Patient: " + patient.getMedicalRecordNumber() +
                        " with Doctor: " + doctor.getUser().getFullName() + " on " + dto.getAppointmentDate() + " " + dto.getAppointmentTime(), null);

        // Notify Doctor
        notificationService.sendNotification(doctor.getUser(), "New Appointment Booked",
                "Patient " + patient.getUser().getFullName() + " booked an appointment on " +
                        dto.getAppointmentDate() + " at " + dto.getAppointmentTime() + " (Apt: " + aptNumber + ").",
                "APPOINTMENT", "/doctor/appointments");

        // Notify Patient
        notificationService.sendNotification(patient.getUser(), "Appointment Confirmed",
                "Your appointment with Dr. " + doctor.getUser().getFullName() + " is confirmed for " +
                        dto.getAppointmentDate() + " at " + dto.getAppointmentTime() + ".",
                "APPOINTMENT", "/patient/appointments");

        return saved;
    }

    @Transactional(readOnly = true)
    public List<LocalTime> getAvailableTimeSlots(Long doctorId, LocalDate date) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new IllegalArgumentException("Doctor not found"));

        // Generate standard slots from 09:00 to 17:00 at 30 min intervals
        List<LocalTime> allSlots = new ArrayList<>();
        LocalTime start = LocalTime.of(9, 0);
        LocalTime end = LocalTime.of(17, 0);
        while (start.isBefore(end)) {
            // Skip 13:00 - 14:00 lunch break
            if (start.getHour() != 13) {
                allSlots.add(start);
            }
            start = start.plusMinutes(30);
        }

        // Fetch already booked slots for this doctor on that date
        List<Appointment> booked = appointmentRepository.findByDoctorAndAppointmentDateOrderByAppointmentTimeAsc(doctor, date);
        List<LocalTime> bookedTimes = booked.stream()
                .filter(a -> a.getStatus() != AppointmentStatus.CANCELLED && a.getStatus() != AppointmentStatus.REJECTED)
                .map(Appointment::getAppointmentTime)
                .toList();

        // Filter out booked slots
        return allSlots.stream()
                .filter(slot -> !bookedTimes.contains(slot))
                .toList();
    }

    @Transactional
    public Appointment updateStatus(Long appointmentId, AppointmentStatus newStatus, String notes) {
        Appointment apt = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found: " + appointmentId));

        AppointmentStatus oldStatus = apt.getStatus();
        apt.setStatus(newStatus);
        if (notes != null && !notes.trim().isEmpty()) {
            apt.setReceptionistNotes(notes);
        }
        Appointment updated = appointmentRepository.save(apt);

        auditLogService.log("UPDATE_APPOINTMENT_STATUS", "Appointment", appointmentId.toString(),
                "Status transitioned from " + oldStatus + " to " + newStatus, null);

        // Status change notifications
        notificationService.sendNotification(apt.getPatient().getUser(), "Appointment Status Updated",
                "Your appointment (" + apt.getAppointmentNumber() + ") is now: " + newStatus,
                "APPOINTMENT", "/patient/appointments");

        return updated;
    }

    @Transactional
    public void cancelAppointment(Long appointmentId, User requestedBy) {
        Appointment apt = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found"));

        apt.setStatus(AppointmentStatus.CANCELLED);
        appointmentRepository.save(apt);

        auditLogService.log("CANCEL_APPOINTMENT", "Appointment", appointmentId.toString(),
                "Cancelled by " + requestedBy.getUsername(), null);

        notificationService.sendNotification(apt.getDoctor().getUser(), "Appointment Cancelled",
                "Appointment " + apt.getAppointmentNumber() + " with patient " +
                        apt.getPatient().getUser().getFullName() + " has been cancelled.",
                "APPOINTMENT", "/doctor/appointments");
    }

    @Transactional(readOnly = true)
    public Optional<Appointment> findById(Long id) {
        return appointmentRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public List<Appointment> findByPatient(Patient patient) {
        return appointmentRepository.findByPatientOrderByAppointmentDateDescAppointmentTimeDesc(patient);
    }

    @Transactional(readOnly = true)
    public List<Appointment> findByDoctor(Doctor doctor) {
        return appointmentRepository.findByDoctorOrderByAppointmentDateDescAppointmentTimeDesc(doctor);
    }

    @Transactional(readOnly = true)
    public List<Appointment> findByDate(LocalDate date) {
        return appointmentRepository.findByAppointmentDateOrderByAppointmentTimeAsc(date);
    }

    @Transactional(readOnly = true)
    public List<Appointment> findAll() {
        return appointmentRepository.findAll();
    }

    @Transactional(readOnly = true)
    public long countTodayAppointments() {
        return appointmentRepository.countTodayAppointments(LocalDate.now());
    }

    private String generateAppointmentNumber() {
        String year = String.valueOf(Year.now().getValue());
        int random = 10000 + (int) (Math.random() * 90000);
        return "APT-" + year + "-" + random;
    }
}
