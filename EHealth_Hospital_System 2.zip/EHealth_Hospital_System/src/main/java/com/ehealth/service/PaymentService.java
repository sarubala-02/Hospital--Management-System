package com.ehealth.service;

import com.ehealth.dto.PaymentRequestDto;
import com.ehealth.entity.*;
import com.ehealth.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentTransactionRepository transactionRepository;
    private final InvoiceRepository invoiceRepository;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;
    private final HospitalSettingService settingService;

    @Value("${payment.gateway.provider:MOCK_SANDBOX}")
    private String gatewayProvider;

    @Value("${payment.gateway.key-id:rzp_test_eHealthDemoKey99}")
    private String gatewayKeyId;

    @Value("${payment.gateway.key-secret:sec_test_mockSecretToken456}")
    private String gatewayKeySecret;

    public PaymentService(PaymentRepository paymentRepository,
                          PaymentTransactionRepository transactionRepository,
                          InvoiceRepository invoiceRepository,
                          AuditLogService auditLogService,
                          NotificationService notificationService,
                          HospitalSettingService settingService) {
        this.paymentRepository = paymentRepository;
        this.transactionRepository = transactionRepository;
        this.invoiceRepository = invoiceRepository;
        this.auditLogService = auditLogService;
        this.notificationService = notificationService;
        this.settingService = settingService;
    }

    @Transactional
    public Payment processOfflinePayment(PaymentRequestDto dto, User receivedBy) {
        Invoice invoice = invoiceRepository.findById(dto.getInvoiceId())
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + dto.getInvoiceId()));

        if (invoice.getStatus() == InvoiceStatus.PAID) {
            throw new IllegalStateException("Invoice is already fully paid.");
        }

        BigDecimal paymentAmount = dto.getAmount();
        if (paymentAmount.compareTo(invoice.getBalanceAmount()) > 0) {
            throw new IllegalArgumentException("Payment amount (" + paymentAmount + ") exceeds remaining balance (" + invoice.getBalanceAmount() + ").");
        }

        String paymentNumber = generatePaymentNumber();

        Payment payment = new Payment(
                paymentNumber,
                invoice,
                paymentAmount,
                dto.getPaymentMethod(),
                PaymentStatus.COMPLETED,
                dto.getTransactionReference() != null ? dto.getTransactionReference() : "OFFLINE-" + System.currentTimeMillis(),
                receivedBy
        );
        payment.setNotes(dto.getNotes());
        Payment savedPayment = paymentRepository.save(payment);

        // Update Invoice Paid and Balance Amounts
        invoice.setPaidAmount(invoice.getPaidAmount().add(paymentAmount));
        invoice.recalculateTotals();
        invoiceRepository.save(invoice);

        auditLogService.log("RECORD_OFFLINE_PAYMENT", "Payment", savedPayment.getId().toString(),
                "Recorded " + dto.getPaymentMethod() + " payment of " + paymentAmount + " for Invoice " + invoice.getInvoiceNumber() +
                        " (Receipt: " + paymentNumber + ")", null);

        notificationService.sendNotification(invoice.getPatient().getUser(), "Payment Received",
                "Receipt " + paymentNumber + ": Payment of " + settingService.getCurrency() + " " + paymentAmount +
                        " for Invoice " + invoice.getInvoiceNumber() + " successfully recorded.",
                "BILLING", "/patient/invoices/" + invoice.getId());

        return savedPayment;
    }

    @Transactional
    public PaymentTransaction initiateSandboxPayment(Long invoiceId, Patient patient) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + invoiceId));

        if (invoice.getStatus() == InvoiceStatus.PAID) {
            throw new IllegalStateException("Invoice is already fully paid.");
        }

        // Security check
        if (!invoice.getPatient().getId().equals(patient.getId())) {
            throw new org.springframework.security.access.AccessDeniedException("Access denied: You can only pay for your own invoices.");
        }

        String txnId = "TXN-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
        String orderId = "order_" + UUID.randomUUID().toString().substring(0, 14);

        PaymentTransaction transaction = new PaymentTransaction(
                txnId,
                invoice,
                patient,
                invoice.getBalanceAmount(),
                settingService.getCurrency(),
                gatewayProvider,
                orderId,
                "INITIATED"
        );

        PaymentTransaction saved = transactionRepository.save(transaction);

        auditLogService.log("INITIATE_SANDBOX_PAYMENT", "PaymentTransaction", saved.getId().toString(),
                "Initiated sandbox payment order " + orderId + " for Invoice " + invoice.getInvoiceNumber() +
                        " amount: " + invoice.getBalanceAmount(), null);

        return saved;
    }

    @Transactional
    public Payment verifyAndCompleteOnlinePayment(String transactionId, String gatewayPaymentId, String gatewaySignature) {
        PaymentTransaction txn = transactionRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid payment transaction ID: " + transactionId));

        if ("VERIFIED".equals(txn.getStatus()) || "SUCCESS".equals(txn.getStatus())) {
            throw new IllegalStateException("Transaction has already been verified and processed.");
        }

        Invoice invoice = txn.getInvoice();
        if (invoice.getStatus() == InvoiceStatus.PAID) {
            throw new IllegalStateException("Invoice is already settled.");
        }

        // Server-Side Verification:
        // In real Razorpay: HMAC-SHA256(order_id + "|" + payment_id, secret) == signature
        // In our sandbox engine: We verify that signature equals expected hash or sandbox mock signature
        boolean isValid = verifySandboxSignature(txn.getGatewayOrderId(), gatewayPaymentId, gatewaySignature);

        if (!isValid) {
            txn.setStatus("FAILED");
            txn.setGatewayRawResponse("Signature verification failed for payment " + gatewayPaymentId);
            transactionRepository.save(txn);
            auditLogService.log("PAYMENT_VERIFICATION_FAILED", "PaymentTransaction", txn.getId().toString(),
                    "Cryptographic signature check failed for gateway payment " + gatewayPaymentId, null);
            throw new SecurityException("Payment verification failed! Potential tampering detected.");
        }

        // Verification Success: Update Transaction
        txn.setStatus("VERIFIED");
        txn.setGatewayPaymentId(gatewayPaymentId);
        txn.setGatewaySignature(gatewaySignature);
        txn.setGatewayRawResponse("VERIFIED_OK: payment_id=" + gatewayPaymentId + ", timestamp=" + LocalDateTime.now());
        transactionRepository.save(txn);

        // Record Completed Payment
        String paymentNumber = generatePaymentNumber();
        Payment payment = new Payment(
                paymentNumber,
                invoice,
                txn.getAmount(),
                PaymentMethod.ONLINE_GATEWAY,
                PaymentStatus.COMPLETED,
                "ONLINE-GW:" + gatewayPaymentId,
                invoice.getPatient().getUser()
        );
        payment.setNotes("Online Sandbox Settlement: " + gatewayProvider + " Txn: " + txn.getTransactionId());
        Payment savedPayment = paymentRepository.save(payment);

        // Update Invoice
        invoice.setPaidAmount(invoice.getPaidAmount().add(txn.getAmount()));
        invoice.recalculateTotals();
        invoiceRepository.save(invoice);

        auditLogService.log("ONLINE_PAYMENT_SUCCESS", "Payment", savedPayment.getId().toString(),
                "Online sandbox payment " + paymentNumber + " verified for " + txn.getAmount() + " (Invoice: " + invoice.getInvoiceNumber() + ")", null);

        notificationService.sendNotification(invoice.getPatient().getUser(), "Online Payment Verified",
                "Your online payment of " + txn.getCurrency() + " " + txn.getAmount() +
                        " for Invoice " + invoice.getInvoiceNumber() + " was successfully verified. Receipt: " + paymentNumber,
                "BILLING", "/patient/invoices/" + invoice.getId());

        return savedPayment;
    }

    private boolean verifySandboxSignature(String orderId, String paymentId, String clientSignature) {
        if (clientSignature == null || clientSignature.trim().isEmpty()) {
            return false;
        }
        // Accepts test sandbox tokens or computes HMAC SHA-256 simulation
        if ("SANDBOX_MOCK_VALID_SIGNATURE".equalsIgnoreCase(clientSignature)) {
            return true;
        }
        try {
            String payload = orderId + "|" + paymentId;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest((payload + gatewayKeySecret).getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().equalsIgnoreCase(clientSignature) || clientSignature.startsWith("sig_test_");
        } catch (Exception e) {
            return false;
        }
    }

    @Transactional(readOnly = true)
    public List<Payment> findPaymentsByInvoice(Invoice invoice) {
        return paymentRepository.findByInvoice(invoice);
    }

    @Transactional(readOnly = true)
    public Optional<Payment> findById(Long id) {
        return paymentRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public List<Payment> findAllPayments() {
        return paymentRepository.findAllByOrderByPaymentDateDesc();
    }

    public String getGatewayKeyId() {
        return gatewayKeyId;
    }

    public String getGatewayProvider() {
        return gatewayProvider;
    }

    private String generatePaymentNumber() {
        String year = String.valueOf(Year.now().getValue());
        int random = 10000 + (int) (Math.random() * 90000);
        return "PAY-" + year + "-" + random;
    }
}
