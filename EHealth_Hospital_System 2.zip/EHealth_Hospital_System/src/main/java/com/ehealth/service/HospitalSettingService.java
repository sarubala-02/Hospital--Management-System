package com.ehealth.service;

import com.ehealth.entity.HospitalSetting;
import com.ehealth.repository.HospitalSettingRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class HospitalSettingService {

    private final HospitalSettingRepository settingRepository;

    @Value("${hospital.name:Apex Care Multi-Speciality Hospital & Research Center}")
    private String defaultHospitalName;

    @Value("${hospital.tax-rate:0.05}")
    private BigDecimal defaultTaxRate;

    @Value("${hospital.currency:INR}")
    private String defaultCurrency;

    public HospitalSettingService(HospitalSettingRepository settingRepository) {
        this.settingRepository = settingRepository;
    }

    @Transactional(readOnly = true)
    public String getSetting(String key, String defaultValue) {
        return settingRepository.findByKey(key)
                .map(HospitalSetting::getValue)
                .orElse(defaultValue);
    }

    @Transactional(readOnly = true)
    public String getHospitalName() {
        return getSetting("HOSPITAL_NAME", defaultHospitalName);
    }

    @Transactional(readOnly = true)
    public BigDecimal getTaxRate() {
        String val = getSetting("TAX_RATE_PERCENT", "5.0");
        try {
            return new BigDecimal(val).divide(new BigDecimal("100"), 4, java.math.RoundingMode.HALF_UP);
        } catch (Exception e) {
            return defaultTaxRate;
        }
    }

    @Transactional(readOnly = true)
    public String getCurrency() {
        return getSetting("CURRENCY_CODE", defaultCurrency);
    }

    @Transactional(readOnly = true)
    public List<HospitalSetting> getAllSettings() {
        return settingRepository.findAll();
    }

    @Transactional
    public void saveSetting(String key, String value, String description) {
        HospitalSetting setting = settingRepository.findByKey(key)
                .orElse(new HospitalSetting(key, value, description));
        setting.setValue(value);
        if (description != null) {
            setting.setDescription(description);
        }
        settingRepository.save(setting);
    }
}
