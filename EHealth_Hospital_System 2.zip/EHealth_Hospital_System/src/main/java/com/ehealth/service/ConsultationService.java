package com.ehealth.service;

import com.ehealth.dto.ConsultationDto;
import com.ehealth.entity.*;
import com.ehealth.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class ConsultationService {

    private final ConsultationRepository consultationRepository;
    private final PrescriptionRepository prescriptionRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final AppointmentRepository appointmentRepository;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;

    public ConsultationService(ConsultationRepository consultationRepository,
                               PrescriptionRepository prescriptionRepository,
                               MedicalRecordRepository medicalRecordRepository,
                               AppointmentRepository appointmentRepository,
                               AuditLogService auditLogService,
                               NotificationService notificationService) {
        this.consultationRepository = consultationRepository;
        this.prescriptionRepository = prescriptionRepository;
        this.medicalRecordRepository = medicalRecordRepository;
        this.appointmentRepository = appointmentRepository;
        this.auditLogService = auditLogService;
        this.notificationService = notificationService;
    }

    @Transactional
    public Consultation saveConsultation(Doctor doctor, ConsultationDto dto) {
        Appointment appointment = appointmentRepository.findById(dto.getAppointmentId())
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found: " + dto.getAppointmentId()));

        // Security boundary check: Ensure this doctor is assigned to the appointment
        if (!appointment.getDoctor().getId().equals(doctor.getId())) {
            throw new org.springframework.security.access.AccessDeniedException("Unauthorized: You are not the assigned doctor for this appointment.");
        }

        BigDecimal fee = dto.getConsultationFee() != null ? dto.getConsultationFee() : doctor.getConsultationFee();

        Consultation consultation = consultationRepository.findByAppointment(appointment)
                .orElse(new Consultation(
                        appointment,
                        doctor,
                        appointment.getPatient(),
                        dto.getSymptoms(),
                        dto.getDiagnosis(),
                        dto.getClinicalNotes(),
                        dto.getFollowUpDate(),
                        fee
                ));

        consultation.setSymptoms(dto.getSymptoms());
        consultation.setDiagnosis(dto.getDiagnosis());
        consultation.setClinicalNotes(dto.getClinicalNotes());
        consultation.setFollowUpDate(dto.getFollowUpDate());
        consultation.setConsultationFee(fee);
        consultation.setBillable(true);

        Consultation savedConsultation = consultationRepository.save(consultation);

        // Save Prescription if items or advice provided
        if ((dto.getPrescriptionItems() != null && !dto.getPrescriptionItems().isEmpty()) ||
            (dto.getGeneralAdvice() != null && !dto.getGeneralAdvice().trim().isEmpty())) {

            Prescription prescription = prescriptionRepository.findByConsultation(savedConsultation)
                    .orElse(new Prescription(savedConsultation, appointment.getPatient(), doctor, dto.getGeneralAdvice()));

            prescription.setGeneralAdvice(dto.getGeneralAdvice());
            prescription.getItems().clear();

            if (dto.getPrescriptionItems() != null) {
                for (ConsultationDto.PrescriptionItemDto itemDto : dto.getPrescriptionItems()) {
                    if (itemDto.getMedicineName() != null && !itemDto.getMedicineName().trim().isEmpty()) {
                        PrescriptionItem item = new PrescriptionItem(
                                itemDto.getMedicineName(),
                                itemDto.getDosage(),
                                itemDto.getFrequency(),
                                itemDto.getDuration(),
                                itemDto.getSpecialInstructions()
                        );
                        prescription.addItem(item);
                    }
                }
            }
            prescriptionRepository.save(prescription);
        }

        // Add Medical Record entry
        MedicalRecord record = new MedicalRecord(
                appointment.getPatient(),
                "CONSULTATION",
                "Consultation with Dr. " + doctor.getUser().getFullName(),
                "Diagnosis: " + dto.getDiagnosis() + "\nSymptoms: " + dto.getSymptoms() + "\nNotes: " + dto.getClinicalNotes(),
                doctor
        );
        medicalRecordRepository.save(record);

        // Mark appointment as COMPLETED
        appointment.setStatus(AppointmentStatus.COMPLETED);
        appointmentRepository.save(appointment);

        auditLogService.log("RECORD_CONSULTATION", "Consultation", savedConsultation.getId().toString(),
                "Dr. " + doctor.getUser().getFullName() + " recorded consultation for Patient " +
                        appointment.getPatient().getMedicalRecordNumber() + " with fee: " + fee, null);

        notificationService.sendNotification(appointment.getPatient().getUser(), "Consultation Completed",
                "Your consultation with Dr. " + doctor.getUser().getFullName() + " is complete. Prescription and records are now available in your portal.",
                "MEDICAL_RECORD", "/patient/records");

        return savedConsultation;
    }

    @Transactional(readOnly = true)
    public Optional<Consultation> findByAppointmentId(Long appointmentId) {
        return consultationRepository.findByAppointmentId(appointmentId);
    }

    @Transactional(readOnly = true)
    public Optional<Prescription> findPrescriptionByConsultationId(Long consultationId) {
        return prescriptionRepository.findByConsultationId(consultationId);
    }

    @Transactional(readOnly = true)
    public List<Consultation> findByPatient(Patient patient) {
        return consultationRepository.findByPatientOrderByCreatedAtDesc(patient);
    }

    @Transactional(readOnly = true)
    public List<MedicalRecord> findMedicalRecordsByPatient(Patient patient) {
        return medicalRecordRepository.findByPatientOrderByRecordedAtDesc(patient);
    }
}
