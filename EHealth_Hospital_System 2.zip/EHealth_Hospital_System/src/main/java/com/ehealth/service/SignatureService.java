package com.ehealth.service;

import com.ehealth.dto.SignatureDto;
import com.ehealth.entity.ConsentRecord;
import com.ehealth.entity.Patient;
import com.ehealth.entity.SignatureRecord;
import com.ehealth.repository.ConsentRecordRepository;
import com.ehealth.repository.SignatureRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SignatureService {

    private final SignatureRepository signatureRepository;
    private final ConsentRecordRepository consentRecordRepository;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;

    public SignatureService(SignatureRepository signatureRepository,
                            ConsentRecordRepository consentRecordRepository,
                            AuditLogService auditLogService,
                            NotificationService notificationService) {
        this.signatureRepository = signatureRepository;
        this.consentRecordRepository = consentRecordRepository;
        this.auditLogService = auditLogService;
        this.notificationService = notificationService;
    }

    @Transactional
    public ConsentRecord recordSignatureAndConsent(Patient patient, SignatureDto dto, String ipAddress, String userAgent) {
        if (dto.getSignatureDataUrl() == null || !dto.getSignatureDataUrl().startsWith("data:image/")) {
            throw new IllegalArgumentException("Invalid signature image payload");
        }

        // Cryptographic integrity hash (SHA-256) of raw signature raster data
        String signatureHash = computeSha256(dto.getSignatureDataUrl());

        SignatureRecord signatureRecord = new SignatureRecord(
                patient,
                dto.getSignatureDataUrl(),
                signatureHash,
                ipAddress,
                userAgent
        );
        SignatureRecord savedSignature = signatureRepository.save(signatureRecord);

        // Check if previous active consent of this type exists; archive/replace it
        Optional<ConsentRecord> existingConsent = consentRecordRepository
                .findByPatientAndConsentTypeAndRevokedFalse(patient, dto.getConsentType());
        existingConsent.ifPresent(c -> {
            c.setRevoked(true);
            c.setRevocationReason("Superseded by new version signed at " + LocalDateTime.now());
            c.setRevokedAt(LocalDateTime.now());
            consentRecordRepository.save(c);
        });

        ConsentRecord consentRecord = new ConsentRecord(
                patient,
                savedSignature,
                dto.getConsentTitle(),
                dto.getConsentType(),
                "2.0",
                dto.getConsentText()
        );
        ConsentRecord savedConsent = consentRecordRepository.save(consentRecord);

        auditLogService.log("ELECTRONIC_CONSENT_SIGNED", "ConsentRecord", savedConsent.getId().toString(),
                "Patient " + patient.getMedicalRecordNumber() + " executed digital consent: " +
                        dto.getConsentTitle() + " [SHA-256: " + signatureHash.substring(0, 16) + "...]", ipAddress);

        notificationService.sendNotification(patient.getUser(), "Consent Executed",
                "Your signed consent for '" + dto.getConsentTitle() + "' has been securely registered in your medical file.",
                "SYSTEM", "/patient/consent");

        return savedConsent;
    }

    @Transactional(readOnly = true)
    public List<ConsentRecord> getPatientConsents(Patient patient) {
        return consentRecordRepository.findByPatientOrderBySignedAtDesc(patient);
    }

    @Transactional(readOnly = true)
    public Optional<ConsentRecord> getConsentById(Long id) {
        return consentRecordRepository.findById(id);
    }

    @Transactional
    public void revokeConsent(Long consentId, Patient patient, String reason) {
        ConsentRecord consent = consentRecordRepository.findById(consentId)
                .orElseThrow(() -> new IllegalArgumentException("Consent not found: " + consentId));

        if (!consent.getPatient().getId().equals(patient.getId())) {
            throw new org.springframework.security.access.AccessDeniedException("Unauthorized to revoke this consent record");
        }

        consent.setRevoked(true);
        consent.setRevocationReason(reason);
        consent.setRevokedAt(LocalDateTime.now());
        consentRecordRepository.save(consent);

        auditLogService.log("REVOKE_CONSENT", "ConsentRecord", consentId.toString(),
                "Patient revoked consent: " + consent.getConsentTitle() + ". Reason: " + reason, null);
    }

    private String computeSha256(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 algorithm error", e);
        }
    }
}
