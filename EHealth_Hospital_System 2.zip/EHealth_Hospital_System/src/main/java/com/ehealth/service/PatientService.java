package com.ehealth.service;

import com.ehealth.dto.PatientRegistrationDto;
import com.ehealth.entity.Patient;
import com.ehealth.entity.Role;
import com.ehealth.entity.RoleName;
import com.ehealth.entity.User;
import com.ehealth.repository.PatientRepository;
import com.ehealth.repository.RoleRepository;
import com.ehealth.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Year;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PatientService {

    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;

    public PatientService(PatientRepository patientRepository, UserRepository userRepository,
                          RoleRepository roleRepository, PasswordEncoder passwordEncoder,
                          AuditLogService auditLogService, NotificationService notificationService) {
        this.patientRepository = patientRepository;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.auditLogService = auditLogService;
        this.notificationService = notificationService;
    }

    @Transactional
    public Patient registerPatient(PatientRegistrationDto dto) {
        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("Username is already taken: " + dto.getUsername());
        }
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email is already registered: " + dto.getEmail());
        }

        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setFullName(dto.getFullName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setActive(true);

        Role patientRole = roleRepository.findByName(RoleName.ROLE_PATIENT)
                .orElseThrow(() -> new IllegalStateException("ROLE_PATIENT not initialized"));
        user.getRoles().add(patientRole);

        User savedUser = userRepository.save(user);

        // Generate unique Medical Record Number (MRN)
        String mrn = generateUniqueMrn();

        Patient patient = new Patient(
                savedUser,
                mrn,
                dto.getDateOfBirth(),
                dto.getGender(),
                dto.getBloodGroup(),
                dto.getAddress(),
                dto.getEmergencyContactName(),
                dto.getEmergencyContactPhone()
        );
        patient.setAllergies(dto.getAllergies());
        patient.setChronicConditions(dto.getChronicConditions());

        Patient savedPatient = patientRepository.save(patient);

        auditLogService.log("REGISTER_PATIENT", "Patient", savedPatient.getId().toString(),
                "Registered new patient with MRN: " + mrn, null);

        notificationService.sendNotification(savedUser, "Welcome to Apex Care Hospital",
                "Your patient account and Medical Record Number (" + mrn + ") have been successfully created.",
                "SYSTEM", "/patient/dashboard");

        return savedPatient;
    }

    @Transactional(readOnly = true)
    public Optional<Patient> findByUser(User user) {
        return patientRepository.findByUser(user);
    }

    @Transactional(readOnly = true)
    public Optional<Patient> findByUserId(Long userId) {
        return patientRepository.findByUserId(userId);
    }

    @Transactional(readOnly = true)
    public Optional<Patient> findById(Long id) {
        return patientRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<Patient> findByMrn(String mrn) {
        return patientRepository.findByMedicalRecordNumber(mrn);
    }

    @Transactional(readOnly = true)
    public List<Patient> findAllPatients() {
        return patientRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Patient> searchPatients(String query) {
        if (query == null || query.trim().isEmpty()) {
            return patientRepository.findAll();
        }
        return patientRepository.searchPatients(query.trim());
    }

    @Transactional
    public Patient updatePatient(Long patientId, PatientRegistrationDto dto) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new IllegalArgumentException("Patient not found: " + patientId));

        User user = patient.getUser();
        if (user != null) {
            user.setFullName(dto.getFullName());
            user.setPhone(dto.getPhone());
            if (dto.getEmail() != null && !dto.getEmail().equals(user.getEmail())) {
                if (userRepository.existsByEmail(dto.getEmail())) {
                    throw new IllegalArgumentException("Email already in use");
                }
                user.setEmail(dto.getEmail());
            }
            userRepository.save(user);
        }

        patient.setDateOfBirth(dto.getDateOfBirth());
        patient.setGender(dto.getGender());
        patient.setBloodGroup(dto.getBloodGroup());
        patient.setAddress(dto.getAddress());
        patient.setEmergencyContactName(dto.getEmergencyContactName());
        patient.setEmergencyContactPhone(dto.getEmergencyContactPhone());
        patient.setAllergies(dto.getAllergies());
        patient.setChronicConditions(dto.getChronicConditions());

        Patient updated = patientRepository.save(patient);

        auditLogService.log("UPDATE_PATIENT_PROFILE", "Patient", updated.getId().toString(),
                "Updated demographic details for MRN: " + updated.getMedicalRecordNumber(), null);

        return updated;
    }

    private String generateUniqueMrn() {
        String year = String.valueOf(Year.now().getValue());
        String code;
        do {
            int randomNum = 100000 + (int) (Math.random() * 900000);
            code = "MRN-" + year + "-" + randomNum;
        } while (patientRepository.existsByMedicalRecordNumber(code));
        return code;
    }
}
