package com.ehealth.controller;

import com.ehealth.dto.InvoiceCreateDto;
import com.ehealth.dto.PaymentRequestDto;
import com.ehealth.entity.*;
import com.ehealth.security.SecurityUtils;
import com.ehealth.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/billing")
@PreAuthorize("hasRole('BILLING')")
public class BillingController {

    private final BillingService billingService;
    private final PaymentService paymentService;
    private final AppointmentService appointmentService;
    private final PatientService patientService;
    private final DoctorService doctorService;
    private final HospitalSettingService settingService;

    public BillingController(BillingService billingService, PaymentService paymentService,
                             AppointmentService appointmentService, PatientService patientService,
                             DoctorService doctorService, HospitalSettingService settingService) {
        this.billingService = billingService;
        this.paymentService = paymentService;
        this.appointmentService = appointmentService;
        this.patientService = patientService;
        this.doctorService = doctorService;
        this.settingService = settingService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("financials", billingService.getFinancialSummary());
        model.addAttribute("recentInvoices", billingService.findAllInvoices());
        model.addAttribute("recentPayments", paymentService.findAllPayments());
        model.addAttribute("currency", settingService.getCurrency());
        return "billing/dashboard";
    }

    @GetMapping("/invoices")
    public String invoices(@RequestParam(value = "status", required = false) InvoiceStatus status, Model model) {
        List<Invoice> invoices = (status != null)
                ? billingService.findByStatus(status)
                : billingService.findAllInvoices();

        model.addAttribute("invoices", invoices);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("statuses", InvoiceStatus.values());
        model.addAttribute("currency", settingService.getCurrency());
        return "billing/invoices";
    }

    @GetMapping("/invoices/{id}")
    public String invoiceDetail(@PathVariable Long id, Model model) {
        Invoice invoice = billingService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + id));

        model.addAttribute("invoice", invoice);
        model.addAttribute("payments", paymentService.findPaymentsByInvoice(invoice));
        model.addAttribute("currency", settingService.getCurrency());
        return "billing/invoice-detail";
    }

    @PostMapping("/invoices/{id}/add-item")
    public String addItem(@PathVariable Long id,
                          @RequestParam String description,
                          @RequestParam String category,
                          @RequestParam(defaultValue = "1") int quantity,
                          @RequestParam BigDecimal unitPrice,
                          RedirectAttributes redirectAttributes) {
        try {
            billingService.addItemToInvoice(id, description, category, quantity, unitPrice);
            redirectAttributes.addFlashAttribute("successMessage", "Item successfully added to invoice.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/billing/invoices/" + id;
    }

    @GetMapping("/invoices/create")
    public String createInvoiceForm(@RequestParam(value = "appointmentId", required = false) Long appointmentId,
                                    Model model) {
        InvoiceCreateDto dto = new InvoiceCreateDto();
        if (appointmentId != null) {
            appointmentService.findById(appointmentId).ifPresent(apt -> {
                dto.setAppointmentId(apt.getId());
                dto.setPatientId(apt.getPatient().getId());
                dto.setDoctorId(apt.getDoctor().getId());
                model.addAttribute("selectedAppointment", apt);
            });
        }

        // Completed appointments eligible for billing
        List<Appointment> completedAppointments = appointmentService.findAll().stream()
                .filter(a -> a.getStatus() == AppointmentStatus.COMPLETED)
                .toList();

        model.addAttribute("invoiceDto", dto);
        model.addAttribute("patients", patientService.findAllPatients());
        model.addAttribute("doctors", doctorService.findAllDoctors());
        model.addAttribute("completedAppointments", completedAppointments);
        model.addAttribute("currency", settingService.getCurrency());
        return "billing/create-invoice";
    }

    @PostMapping("/invoices/generate-from-appointment")
    public String generateFromAppointment(@RequestParam Long appointmentId, RedirectAttributes redirectAttributes) {
        User currentUser = SecurityUtils.getCurrentUser().orElse(null);
        try {
            Invoice inv = billingService.generateInvoiceFromAppointment(appointmentId, currentUser);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Invoice " + inv.getInvoiceNumber() + " generated from consultation charges.");
            return "redirect:/billing/invoices/" + inv.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/billing/invoices/create";
        }
    }

    @PostMapping("/invoices/create")
    public String createCustomInvoice(@Valid @ModelAttribute("invoiceDto") InvoiceCreateDto dto,
                                      BindingResult bindingResult,
                                      RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please select a patient and provide valid items.");
            return "redirect:/billing/invoices/create";
        }

        User currentUser = SecurityUtils.getCurrentUser().orElse(null);
        try {
            Invoice inv = billingService.createCustomInvoice(dto, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Invoice created successfully: " + inv.getInvoiceNumber());
            return "redirect:/billing/invoices/" + inv.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/billing/invoices/create";
        }
    }

    @GetMapping("/invoices/{id}/payment")
    public String recordPaymentForm(@PathVariable Long id, Model model) {
        Invoice invoice = billingService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + id));

        PaymentRequestDto dto = new PaymentRequestDto();
        dto.setInvoiceId(id);
        dto.setAmount(invoice.getBalanceAmount());
        dto.setPaymentMethod(PaymentMethod.CASH);

        model.addAttribute("invoice", invoice);
        model.addAttribute("paymentDto", dto);
        model.addAttribute("paymentMethods", List.of(PaymentMethod.CASH, PaymentMethod.CARD_TERMINAL, PaymentMethod.BANK_TRANSFER));
        model.addAttribute("currency", settingService.getCurrency());
        return "billing/record-payment";
    }

    @PostMapping("/invoices/{id}/payment")
    public String processOfflinePayment(@PathVariable Long id,
                                        @Valid @ModelAttribute("paymentDto") PaymentRequestDto dto,
                                        BindingResult bindingResult,
                                        RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid payment amount.");
            return "redirect:/billing/invoices/" + id + "/payment";
        }

        User currentUser = SecurityUtils.getCurrentUser().orElse(null);
        try {
            Payment payment = paymentService.processOfflinePayment(dto, currentUser);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Payment registered successfully! Receipt Number: " + payment.getPaymentNumber());
            return "redirect:/billing/invoices/" + id;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Payment recording failed: " + e.getMessage());
            return "redirect:/billing/invoices/" + id + "/payment";
        }
    }

    @GetMapping("/reports")
    public String financialReports(Model model) {
        model.addAttribute("financials", billingService.getFinancialSummary());
        model.addAttribute("payments", paymentService.findAllPayments());
        model.addAttribute("currency", settingService.getCurrency());
        return "billing/reports";
    }
}
