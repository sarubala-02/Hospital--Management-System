package com.ehealth.controller;

import com.ehealth.dto.AppointmentBookingDto;
import com.ehealth.dto.PatientRegistrationDto;
import com.ehealth.entity.Appointment;
import com.ehealth.entity.AppointmentStatus;
import com.ehealth.entity.Patient;
import com.ehealth.service.AppointmentService;
import com.ehealth.service.DoctorService;
import com.ehealth.service.HospitalSettingService;
import com.ehealth.service.PatientService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Controller
@RequestMapping("/receptionist")
@PreAuthorize("hasRole('RECEPTIONIST')")
public class ReceptionistController {

    private final PatientService patientService;
    private final DoctorService doctorService;
    private final AppointmentService appointmentService;
    private final HospitalSettingService settingService;

    public ReceptionistController(PatientService patientService, DoctorService doctorService,
                                  AppointmentService appointmentService, HospitalSettingService settingService) {
        this.patientService = patientService;
        this.doctorService = doctorService;
        this.appointmentService = appointmentService;
        this.settingService = settingService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        LocalDate today = LocalDate.now();
        List<Appointment> todayAppointments = appointmentService.findByDate(today);

        long waitingCount = todayAppointments.stream()
                .filter(a -> a.getStatus() == AppointmentStatus.CONFIRMED || a.getStatus() == AppointmentStatus.CHECKED_IN)
                .count();

        model.addAttribute("todayAppointments", todayAppointments);
        model.addAttribute("waitingCount", waitingCount);
        model.addAttribute("totalToday", todayAppointments.size());
        model.addAttribute("currency", settingService.getCurrency());
        return "receptionist/dashboard";
    }

    @GetMapping("/patients")
    public String searchPatients(@RequestParam(value = "query", required = false) String query, Model model) {
        List<Patient> patients = patientService.searchPatients(query);
        model.addAttribute("patients", patients);
        model.addAttribute("query", query);
        return "receptionist/patients";
    }

    @GetMapping("/patients/new")
    public String newPatientForm(Model model) {
        if (!model.containsAttribute("registrationDto")) {
            model.addAttribute("registrationDto", new PatientRegistrationDto());
        }
        return "receptionist/register-patient";
    }

    @PostMapping("/patients/new")
    public String registerPatient(@Valid @ModelAttribute("registrationDto") PatientRegistrationDto dto,
                                  BindingResult bindingResult,
                                  RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "receptionist/register-patient";
        }
        try {
            Patient patient = patientService.registerPatient(dto);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Patient successfully registered! MRN: " + patient.getMedicalRecordNumber());
            return "redirect:/receptionist/appointments/book?patientId=" + patient.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/receptionist/patients/new";
        }
    }

    @GetMapping("/appointments")
    public String dailyAppointments(@RequestParam(value = "date", required = false)
                                    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                    Model model) {
        LocalDate targetDate = date != null ? date : LocalDate.now();
        model.addAttribute("selectedDate", targetDate);
        model.addAttribute("appointments", appointmentService.findByDate(targetDate));
        return "receptionist/appointments";
    }

    @GetMapping("/appointments/book")
    public String bookAppointmentForm(@RequestParam(value = "patientId", required = false) Long patientId,
                                      Model model) {
        AppointmentBookingDto dto = new AppointmentBookingDto();
        if (patientId != null) {
            dto.setPatientId(patientId);
            patientService.findById(patientId).ifPresent(p -> model.addAttribute("selectedPatient", p));
        }
        dto.setAppointmentDate(LocalDate.now());

        model.addAttribute("bookingDto", dto);
        model.addAttribute("patients", patientService.findAllPatients());
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        model.addAttribute("doctors", doctorService.findAllAvailableDoctors());
        return "receptionist/book-appointment";
    }

    @PostMapping("/appointments/book")
    public String bookAppointmentSubmit(@Valid @ModelAttribute("bookingDto") AppointmentBookingDto dto,
                                        BindingResult bindingResult,
                                        RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please provide all required appointment details.");
            return "redirect:/receptionist/appointments/book" + (dto.getPatientId() != null ? "?patientId=" + dto.getPatientId() : "");
        }

        try {
            Patient patient = patientService.findById(dto.getPatientId())
                    .orElseThrow(() -> new IllegalArgumentException("Patient not selected"));

            Appointment apt = appointmentService.bookAppointment(patient, dto);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Appointment booked successfully! Appointment Number: " + apt.getAppointmentNumber());
            return "redirect:/receptionist/appointments?date=" + dto.getAppointmentDate();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Booking failed: " + e.getMessage());
            return "redirect:/receptionist/appointments/book" + (dto.getPatientId() != null ? "?patientId=" + dto.getPatientId() : "");
        }
    }

    @PostMapping("/appointments/{id}/check-in")
    public String checkInPatient(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            appointmentService.updateStatus(id, AppointmentStatus.CHECKED_IN, "Checked in at reception desk");
            redirectAttributes.addFlashAttribute("successMessage", "Patient checked in and doctor alerted.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/receptionist/dashboard";
    }

    @GetMapping("/api/slots")
    @ResponseBody
    public List<LocalTime> getAvailableSlots(@RequestParam Long doctorId,
                                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return appointmentService.getAvailableTimeSlots(doctorId, date);
    }
}
