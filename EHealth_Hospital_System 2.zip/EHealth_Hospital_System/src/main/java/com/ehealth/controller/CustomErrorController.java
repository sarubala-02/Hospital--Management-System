package com.ehealth.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomErrorController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Object message = request.getAttribute(RequestDispatcher.ERROR_MESSAGE);

        int statusCode = 500;
        String title = "Internal Server Error";
        String description = "An unexpected error occurred in the hospital management portal.";

        if (status != null) {
            statusCode = Integer.parseInt(status.toString());
            if (statusCode == HttpStatus.NOT_FOUND.value()) {
                title = "404 - Page Not Found";
                description = "The requested medical portal page or clinical resource could not be found.";
            } else if (statusCode == HttpStatus.FORBIDDEN.value()) {
                title = "403 - Clinical Access Restricted";
                description = "You do not possess the required clinical authorization or role to access this medical resource.";
            }
        }

        model.addAttribute("statusCode", statusCode);
        model.addAttribute("errorTitle", title);
        model.addAttribute("errorMessage", message != null && !message.toString().isEmpty() ? message.toString() : description);
        return "error";
    }
}
