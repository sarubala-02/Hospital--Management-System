package com.ehealth.controller;

import com.ehealth.entity.Invoice;
import com.ehealth.entity.Payment;
import com.ehealth.entity.User;
import com.ehealth.security.SecurityUtils;
import com.ehealth.service.BillingService;
import com.ehealth.service.PaymentService;
import com.ehealth.service.PdfService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class PdfReportController {

    private final BillingService billingService;
    private final PaymentService paymentService;
    private final PdfService pdfService;

    public PdfReportController(BillingService billingService, PaymentService paymentService, PdfService pdfService) {
        this.billingService = billingService;
        this.paymentService = paymentService;
        this.pdfService = pdfService;
    }

    @GetMapping("/invoices/{id}/pdf")
    public ResponseEntity<byte[]> downloadInvoicePdf(@PathVariable Long id) {
        Invoice invoice = billingService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + id));

        // Authorization check: Admin, Billing, Doctor of appointment, or Patient
        User user = SecurityUtils.getCurrentUser()
                .orElseThrow(() -> new AccessDeniedException("Authentication required"));

        boolean isPatient = invoice.getPatient().getUser().getId().equals(user.getId());
        boolean isDoctor = invoice.getDoctor() != null && invoice.getDoctor().getUser().getId().equals(user.getId());
        boolean isStaff = SecurityUtils.hasRole("ROLE_ADMIN") || SecurityUtils.hasRole("ROLE_BILLING") || SecurityUtils.hasRole("ROLE_RECEPTIONIST");

        if (!isPatient && !isDoctor && !isStaff) {
            throw new AccessDeniedException("Unauthorized to download this invoice PDF");
        }

        byte[] pdfBytes = pdfService.generateInvoicePdf(invoice);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + invoice.getInvoiceNumber() + ".pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    @GetMapping("/receipts/{id}/pdf")
    public ResponseEntity<byte[]> downloadReceiptPdf(@PathVariable Long id) {
        Payment payment = paymentService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found: " + id));

        User user = SecurityUtils.getCurrentUser()
                .orElseThrow(() -> new AccessDeniedException("Authentication required"));

        boolean isPatient = payment.getInvoice().getPatient().getUser().getId().equals(user.getId());
        boolean isStaff = SecurityUtils.hasRole("ROLE_ADMIN") || SecurityUtils.hasRole("ROLE_BILLING");

        if (!isPatient && !isStaff) {
            throw new AccessDeniedException("Unauthorized to download this payment receipt");
        }

        byte[] pdfBytes = pdfService.generateReceiptPdf(payment);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + payment.getPaymentNumber() + ".pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
