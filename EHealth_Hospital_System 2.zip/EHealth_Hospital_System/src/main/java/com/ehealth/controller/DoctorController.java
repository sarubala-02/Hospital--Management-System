package com.ehealth.controller;

import com.ehealth.dto.ConsultationDto;
import com.ehealth.entity.*;
import com.ehealth.security.SecurityUtils;
import com.ehealth.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/doctor")
@PreAuthorize("hasRole('DOCTOR')")
public class DoctorController {

    private final DoctorService doctorService;
    private final AppointmentService appointmentService;
    private final ConsultationService consultationService;
    private final BillingService billingService;
    private final HospitalSettingService settingService;

    public DoctorController(DoctorService doctorService, AppointmentService appointmentService,
                            ConsultationService consultationService, BillingService billingService,
                            HospitalSettingService settingService) {
        this.doctorService = doctorService;
        this.appointmentService = appointmentService;
        this.consultationService = consultationService;
        this.billingService = billingService;
        this.settingService = settingService;
    }

    private Doctor getCurrentDoctor() {
        User user = SecurityUtils.getCurrentUser()
                .orElseThrow(() -> new AccessDeniedException("Doctor authentication required"));
        return doctorService.findByUser(user)
                .orElseThrow(() -> new AccessDeniedException("No doctor profile linked to account " + user.getUsername()));
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Doctor doctor = getCurrentDoctor();
        List<Appointment> allAppointments = appointmentService.findByDoctor(doctor);
        LocalDate today = LocalDate.now();

        List<Appointment> todayAppointments = allAppointments.stream()
                .filter(a -> a.getAppointmentDate().equals(today))
                .toList();

        long pendingCount = allAppointments.stream().filter(a -> a.getStatus() == AppointmentStatus.PENDING || a.getStatus() == AppointmentStatus.CONFIRMED).count();
        long completedCount = allAppointments.stream().filter(a -> a.getStatus() == AppointmentStatus.COMPLETED).count();

        model.addAttribute("doctor", doctor);
        model.addAttribute("todayAppointments", todayAppointments);
        model.addAttribute("pendingCount", pendingCount);
        model.addAttribute("completedCount", completedCount);
        model.addAttribute("totalAssigned", allAppointments.size());
        model.addAttribute("currency", settingService.getCurrency());
        return "doctor/dashboard";
    }

    @GetMapping("/appointments")
    public String appointments(Model model) {
        Doctor doctor = getCurrentDoctor();
        List<Appointment> appointments = appointmentService.findByDoctor(doctor);
        model.addAttribute("doctor", doctor);
        model.addAttribute("appointments", appointments);
        return "doctor/appointments";
    }

    @PostMapping("/appointments/{id}/status")
    public String updateAppointmentStatus(@PathVariable Long id,
                                          @RequestParam AppointmentStatus status,
                                          @RequestParam(required = false) String notes,
                                          RedirectAttributes redirectAttributes) {
        Doctor doctor = getCurrentDoctor();
        Appointment apt = appointmentService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found"));

        if (!apt.getDoctor().getId().equals(doctor.getId())) {
            throw new AccessDeniedException("Forbidden: You cannot modify appointments assigned to other doctors.");
        }

        appointmentService.updateStatus(id, status, notes);
        redirectAttributes.addFlashAttribute("successMessage", "Appointment status updated to " + status);
        return "redirect:/doctor/appointments";
    }

    @GetMapping("/consultation/{appointmentId}")
    public String consultationForm(@PathVariable Long appointmentId, Model model) {
        Doctor doctor = getCurrentDoctor();
        Appointment appointment = appointmentService.findById(appointmentId)
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found: " + appointmentId));

        if (!appointment.getDoctor().getId().equals(doctor.getId())) {
            throw new AccessDeniedException("Security violation: Doctor cannot view patient records of another clinician.");
        }

        ConsultationDto dto = new ConsultationDto();
        dto.setAppointmentId(appointmentId);
        dto.setConsultationFee(doctor.getConsultationFee());

        // Prepopulate if consultation already exists
        consultationService.findByAppointmentId(appointmentId).ifPresent(c -> {
            dto.setSymptoms(c.getSymptoms());
            dto.setDiagnosis(c.getDiagnosis());
            dto.setClinicalNotes(c.getClinicalNotes());
            dto.setFollowUpDate(c.getFollowUpDate());
            dto.setConsultationFee(c.getConsultationFee());
        });

        model.addAttribute("doctor", doctor);
        model.addAttribute("appointment", appointment);
        model.addAttribute("patient", appointment.getPatient());
        model.addAttribute("consultationDto", dto);
        model.addAttribute("currency", settingService.getCurrency());
        return "doctor/consultation";
    }

    @PostMapping("/consultation/save")
    public String saveConsultation(@Valid @ModelAttribute("consultationDto") ConsultationDto dto,
                                   BindingResult bindingResult,
                                   RedirectAttributes redirectAttributes) {
        Doctor doctor = getCurrentDoctor();
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Diagnosis is mandatory.");
            return "redirect:/doctor/consultation/" + dto.getAppointmentId();
        }

        try {
            consultationService.saveConsultation(doctor, dto);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Consultation completed and prescription registered. Charges forwarded to billing.");
            return "redirect:/doctor/appointments";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to save consultation: " + e.getMessage());
            return "redirect:/doctor/consultation/" + dto.getAppointmentId();
        }
    }

    @GetMapping("/schedule")
    public String schedule(Model model) {
        Doctor doctor = getCurrentDoctor();
        model.addAttribute("doctor", doctor);
        model.addAttribute("schedules", doctorService.getDoctorSchedule(doctor));
        model.addAttribute("daysOfWeek", DayOfWeek.values());
        return "doctor/schedule";
    }

    @PostMapping("/schedule/save")
    public String saveSchedule(@RequestParam DayOfWeek dayOfWeek,
                               @RequestParam String startTime,
                               @RequestParam String endTime,
                               @RequestParam(defaultValue = "30") int slotDuration,
                               RedirectAttributes redirectAttributes) {
        Doctor doctor = getCurrentDoctor();
        try {
            doctorService.saveDoctorSchedule(doctor, dayOfWeek, LocalTime.parse(startTime), LocalTime.parse(endTime), slotDuration);
            redirectAttributes.addFlashAttribute("successMessage", "Schedule updated for " + dayOfWeek);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid schedule parameters: " + e.getMessage());
        }
        return "redirect:/doctor/schedule";
    }

    @GetMapping("/patients")
    public String patientHistory(Model model) {
        Doctor doctor = getCurrentDoctor();
        // Secure clinical boundary: only patients that have had an appointment with this doctor
        List<Appointment> doctorAppointments = appointmentService.findByDoctor(doctor);
        List<Patient> assignedPatients = doctorAppointments.stream()
                .map(Appointment::getPatient)
                .distinct()
                .collect(Collectors.toList());

        model.addAttribute("doctor", doctor);
        model.addAttribute("patients", assignedPatients);
        return "doctor/patients";
    }
}
