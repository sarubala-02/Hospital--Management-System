package com.ehealth.controller;

import com.ehealth.dto.StaffRegistrationDto;
import com.ehealth.entity.Department;
import com.ehealth.entity.Doctor;
import com.ehealth.entity.RoleName;
import com.ehealth.entity.User;
import com.ehealth.repository.DepartmentRepository;
import com.ehealth.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserService userService;
    private final DoctorService doctorService;
    private final PatientService patientService;
    private final AppointmentService appointmentService;
    private final BillingService billingService;
    private final AuditLogService auditLogService;
    private final HospitalSettingService settingService;
    private final DepartmentRepository departmentRepository;

    public AdminController(UserService userService, DoctorService doctorService,
                           PatientService patientService, AppointmentService appointmentService,
                           BillingService billingService, AuditLogService auditLogService,
                           HospitalSettingService settingService, DepartmentRepository departmentRepository) {
        this.userService = userService;
        this.doctorService = doctorService;
        this.patientService = patientService;
        this.appointmentService = appointmentService;
        this.billingService = billingService;
        this.auditLogService = auditLogService;
        this.settingService = settingService;
        this.departmentRepository = departmentRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalPatients", patientService.findAllPatients().size());
        model.addAttribute("totalDoctors", doctorService.findAllDoctors().size());
        model.addAttribute("todayAppointments", appointmentService.countTodayAppointments());
        model.addAttribute("financials", billingService.getFinancialSummary());
        model.addAttribute("recentLogs", auditLogService.getRecentLogs());
        model.addAttribute("currency", settingService.getCurrency());
        return "admin/dashboard";
    }

    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userService.findAllUsers());
        model.addAttribute("staffDto", new StaffRegistrationDto());
        model.addAttribute("roles", List.of(RoleName.ROLE_DOCTOR, RoleName.ROLE_RECEPTIONIST, RoleName.ROLE_BILLING));
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        return "admin/users";
    }

    @PostMapping("/users/create")
    public String createStaff(@Valid @ModelAttribute("staffDto") StaffRegistrationDto dto,
                              BindingResult bindingResult,
                              RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Validation failed. Please verify all fields.");
            return "redirect:/admin/users";
        }
        try {
            userService.registerStaff(dto);
            redirectAttributes.addFlashAttribute("successMessage", "Staff account created successfully for " + dto.getUsername());
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/toggle-status")
    public String toggleUserStatus(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            userService.toggleUserActive(id);
            redirectAttributes.addFlashAttribute("successMessage", "User account status updated.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/doctors")
    public String doctors(Model model) {
        model.addAttribute("doctors", doctorService.findAllDoctors());
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        return "admin/doctors";
    }

    @PostMapping("/doctors/{id}/edit")
    public String updateDoctor(@PathVariable Long id,
                               @RequestParam String specialization,
                               @RequestParam String qualification,
                               @RequestParam BigDecimal consultationFee,
                               @RequestParam(required = false) String roomNumber,
                               @RequestParam(defaultValue = "false") boolean available,
                               RedirectAttributes redirectAttributes) {
        try {
            doctorService.updateDoctorProfile(id, specialization, qualification, consultationFee, roomNumber, available);
            redirectAttributes.addFlashAttribute("successMessage", "Doctor details updated successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/doctors";
    }

    @GetMapping("/departments")
    public String departments(Model model) {
        model.addAttribute("departments", departmentRepository.findAll());
        return "admin/departments";
    }

    @PostMapping("/departments/create")
    public String createDepartment(@RequestParam String name,
                                   @RequestParam String code,
                                   @RequestParam String description,
                                   @RequestParam String headOfDepartment,
                                   RedirectAttributes redirectAttributes) {
        try {
            Department dept = new Department(name, code, description, headOfDepartment);
            departmentRepository.save(dept);
            redirectAttributes.addFlashAttribute("successMessage", "Department created successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating department: " + e.getMessage());
        }
        return "redirect:/admin/departments";
    }

    @GetMapping("/audit-logs")
    public String auditLogs(Model model) {
        model.addAttribute("logs", auditLogService.getAllLogs());
        return "admin/audit-logs";
    }

    @GetMapping("/reports")
    public String reports(Model model) {
        model.addAttribute("financials", billingService.getFinancialSummary());
        model.addAttribute("invoices", billingService.findAllInvoices());
        model.addAttribute("appointments", appointmentService.findAll());
        model.addAttribute("currency", settingService.getCurrency());
        return "admin/reports";
    }

    @GetMapping("/settings")
    public String settings(Model model) {
        model.addAttribute("settings", settingService.getAllSettings());
        return "admin/settings";
    }

    @PostMapping("/settings")
    public String updateSettings(@RequestParam String hospitalName,
                                 @RequestParam String taxRatePercent,
                                 @RequestParam String currencyCode,
                                 RedirectAttributes redirectAttributes) {
        try {
            settingService.saveSetting("HOSPITAL_NAME", hospitalName, "Hospital organization name");
            settingService.saveSetting("TAX_RATE_PERCENT", taxRatePercent, "Service tax percentage");
            settingService.saveSetting("CURRENCY_CODE", currencyCode, "Default billing currency");
            redirectAttributes.addFlashAttribute("successMessage", "Hospital system settings updated.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/settings";
    }
}
