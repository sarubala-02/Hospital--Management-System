package com.ehealth.controller;

import com.ehealth.entity.Payment;
import com.ehealth.service.PaymentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/payment")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/sandbox/verify")
    public String verifySandboxPayment(@RequestParam String transactionId,
                                       @RequestParam String gatewayPaymentId,
                                       @RequestParam String gatewaySignature,
                                       RedirectAttributes redirectAttributes) {
        try {
            Payment payment = paymentService.verifyAndCompleteOnlinePayment(transactionId, gatewayPaymentId, gatewaySignature);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Payment of " + payment.getAmount() + " successfully verified by gateway. Receipt: " + payment.getPaymentNumber());
            return "redirect:/patient/invoices/" + payment.getInvoice().getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Payment verification failed: " + e.getMessage());
            return "redirect:/patient/invoices";
        }
    }
}
