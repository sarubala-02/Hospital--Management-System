package com.ehealth.controller;

import com.ehealth.dto.AppointmentBookingDto;
import com.ehealth.dto.PatientRegistrationDto;
import com.ehealth.dto.SignatureDto;
import com.ehealth.entity.*;
import com.ehealth.security.SecurityUtils;
import com.ehealth.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/patient")
@PreAuthorize("hasRole('PATIENT')")
public class PatientController {

    private final PatientService patientService;
    private final AppointmentService appointmentService;
    private final ConsultationService consultationService;
    private final BillingService billingService;
    private final PaymentService paymentService;
    private final SignatureService signatureService;
    private final DoctorService doctorService;
    private final NotificationService notificationService;
    private final HospitalSettingService settingService;

    public PatientController(PatientService patientService, AppointmentService appointmentService,
                             ConsultationService consultationService, BillingService billingService,
                             PaymentService paymentService, SignatureService signatureService,
                             DoctorService doctorService, NotificationService notificationService,
                             HospitalSettingService settingService) {
        this.patientService = patientService;
        this.appointmentService = appointmentService;
        this.consultationService = consultationService;
        this.billingService = billingService;
        this.paymentService = paymentService;
        this.signatureService = signatureService;
        this.doctorService = doctorService;
        this.notificationService = notificationService;
        this.settingService = settingService;
    }

    private Patient getCurrentPatient() {
        User user = SecurityUtils.getCurrentUser()
                .orElseThrow(() -> new AccessDeniedException("User not authenticated"));
        return patientService.findByUser(user)
                .orElseThrow(() -> new AccessDeniedException("No patient profile found for current user"));
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Patient patient = getCurrentPatient();
        List<Appointment> appointments = appointmentService.findByPatient(patient);
        List<Invoice> invoices = billingService.findByPatient(patient);
        List<Notification> unreadNotifs = notificationService.getUnreadNotifications(patient.getUser());

        List<Appointment> upcoming = appointments.stream()
                .filter(a -> !a.getAppointmentDate().isBefore(LocalDate.now()) &&
                        (a.getStatus() == AppointmentStatus.PENDING || a.getStatus() == AppointmentStatus.CONFIRMED))
                .toList();

        List<Invoice> unpaidInvoices = invoices.stream()
                .filter(i -> i.getStatus() == InvoiceStatus.UNPAID || i.getStatus() == InvoiceStatus.PARTIALLY_PAID)
                .toList();

        model.addAttribute("patient", patient);
        model.addAttribute("upcomingAppointments", upcoming);
        model.addAttribute("unpaidInvoices", unpaidInvoices);
        model.addAttribute("recentRecords", consultationService.findByPatient(patient));
        model.addAttribute("unreadNotifications", unreadNotifs);
        model.addAttribute("currency", settingService.getCurrency());
        return "patient/dashboard";
    }

    @GetMapping("/profile")
    public String profile(Model model) {
        Patient patient = getCurrentPatient();
        PatientRegistrationDto dto = new PatientRegistrationDto();
        dto.setFullName(patient.getUser().getFullName());
        dto.setEmail(patient.getUser().getEmail());
        dto.setPhone(patient.getUser().getPhone());
        dto.setDateOfBirth(patient.getDateOfBirth());
        dto.setGender(patient.getGender());
        dto.setBloodGroup(patient.getBloodGroup());
        dto.setAddress(patient.getAddress());
        dto.setEmergencyContactName(patient.getEmergencyContactName());
        dto.setEmergencyContactPhone(patient.getEmergencyContactPhone());
        dto.setAllergies(patient.getAllergies());
        dto.setChronicConditions(patient.getChronicConditions());

        model.addAttribute("patient", patient);
        model.addAttribute("profileDto", dto);
        return "patient/profile";
    }

    @PostMapping("/profile")
    public String updateProfile(@ModelAttribute("profileDto") PatientRegistrationDto dto,
                                RedirectAttributes redirectAttributes) {
        Patient patient = getCurrentPatient();
        try {
            patientService.updatePatient(patient.getId(), dto);
            redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/patient/profile";
    }

    @GetMapping("/appointments")
    public String appointments(Model model) {
        Patient patient = getCurrentPatient();
        model.addAttribute("patient", patient);
        model.addAttribute("appointments", appointmentService.findByPatient(patient));
        return "patient/appointments";
    }

    @GetMapping("/appointments/book")
    public String bookAppointmentForm(Model model) {
        Patient patient = getCurrentPatient();
        AppointmentBookingDto dto = new AppointmentBookingDto();
        dto.setAppointmentDate(LocalDate.now());

        model.addAttribute("patient", patient);
        model.addAttribute("bookingDto", dto);
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        model.addAttribute("doctors", doctorService.findAllAvailableDoctors());
        return "patient/book-appointment";
    }

    @PostMapping("/appointments/book")
    public String bookAppointmentSubmit(@Valid @ModelAttribute("bookingDto") AppointmentBookingDto dto,
                                        BindingResult bindingResult,
                                        RedirectAttributes redirectAttributes) {
        Patient patient = getCurrentPatient();
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please select all required appointment details.");
            return "redirect:/patient/appointments/book";
        }

        try {
            Appointment apt = appointmentService.bookAppointment(patient, dto);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Appointment booked successfully! Appointment Reference: " + apt.getAppointmentNumber());
            return "redirect:/patient/appointments";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/patient/appointments/book";
        }
    }

    @PostMapping("/appointments/{id}/cancel")
    public String cancelAppointment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Patient patient = getCurrentPatient();
        Appointment appointment = appointmentService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Appointment not found"));

        if (!appointment.getPatient().getId().equals(patient.getId())) {
            throw new AccessDeniedException("Access denied: You cannot cancel another patient's appointment.");
        }

        appointmentService.cancelAppointment(id, patient.getUser());
        redirectAttributes.addFlashAttribute("successMessage", "Appointment cancelled successfully.");
        return "redirect:/patient/appointments";
    }

    @GetMapping("/records")
    public String medicalRecords(Model model) {
        Patient patient = getCurrentPatient();
        model.addAttribute("patient", patient);
        model.addAttribute("consultations", consultationService.findByPatient(patient));
        model.addAttribute("records", consultationService.findMedicalRecordsByPatient(patient));
        return "patient/records";
    }

    @GetMapping("/invoices")
    public String invoices(Model model) {
        Patient patient = getCurrentPatient();
        model.addAttribute("patient", patient);
        model.addAttribute("invoices", billingService.findByPatient(patient));
        model.addAttribute("currency", settingService.getCurrency());
        return "patient/invoices";
    }

    @GetMapping("/invoices/{id}")
    public String invoiceDetail(@PathVariable Long id, Model model) {
        Patient patient = getCurrentPatient();
        Invoice invoice = billingService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + id));

        if (!invoice.getPatient().getId().equals(patient.getId())) {
            throw new AccessDeniedException("Access denied: You can only view your own invoices.");
        }

        model.addAttribute("patient", patient);
        model.addAttribute("invoice", invoice);
        model.addAttribute("payments", paymentService.findPaymentsByInvoice(invoice));
        model.addAttribute("currency", settingService.getCurrency());
        return "patient/invoice-detail";
    }

    @GetMapping("/invoices/{id}/pay")
    public String onlinePaymentPage(@PathVariable Long id, Model model) {
        Patient patient = getCurrentPatient();
        Invoice invoice = billingService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + id));

        if (!invoice.getPatient().getId().equals(patient.getId())) {
            throw new AccessDeniedException("Unauthorized to access payment for this invoice.");
        }

        if (invoice.getStatus() == InvoiceStatus.PAID) {
            return "redirect:/patient/invoices/" + id;
        }

        // Initiate Sandbox transaction
        PaymentTransaction txn = paymentService.initiateSandboxPayment(id, patient);

        model.addAttribute("patient", patient);
        model.addAttribute("invoice", invoice);
        model.addAttribute("transaction", txn);
        model.addAttribute("gatewayKey", paymentService.getGatewayKeyId());
        model.addAttribute("gatewayProvider", paymentService.getGatewayProvider());
        model.addAttribute("currency", settingService.getCurrency());
        return "patient/pay";
    }

    @GetMapping("/consent")
    public String signatureAndConsent(Model model) {
        Patient patient = getCurrentPatient();
        model.addAttribute("patient", patient);
        model.addAttribute("consents", signatureService.getPatientConsents(patient));
        model.addAttribute("signatureDto", new SignatureDto());
        return "patient/signature-consent";
    }

    @PostMapping("/consent/sign")
    public String signConsent(@Valid @ModelAttribute("signatureDto") SignatureDto dto,
                              BindingResult bindingResult,
                              HttpServletRequest request,
                              RedirectAttributes redirectAttributes) {
        Patient patient = getCurrentPatient();
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please provide signature drawing before submitting.");
            return "redirect:/patient/consent";
        }

        String ipAddress = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");

        try {
            signatureService.recordSignatureAndConsent(patient, dto, ipAddress, userAgent);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Handwritten signature verified and digital consent successfully recorded with tamper-evident cryptographic hash.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Consent recording failed: " + e.getMessage());
        }
        return "redirect:/patient/consent";
    }

    @PostMapping("/consent/{id}/revoke")
    public String revokeConsent(@PathVariable Long id,
                                @RequestParam String reason,
                                RedirectAttributes redirectAttributes) {
        Patient patient = getCurrentPatient();
        try {
            signatureService.revokeConsent(id, patient, reason);
            redirectAttributes.addFlashAttribute("successMessage", "Consent has been revoked and recorded in audit log.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/patient/consent";
    }

    @GetMapping("/notifications")
    public String notifications(Model model) {
        Patient patient = getCurrentPatient();
        model.addAttribute("notifications", notificationService.getUserNotifications(patient.getUser()));
        return "patient/notifications";
    }

    @PostMapping("/notifications/{id}/read")
    public String markNotificationRead(@PathVariable Long id) {
        Patient patient = getCurrentPatient();
        notificationService.markAsRead(id, patient.getUser());
        return "redirect:/patient/notifications";
    }
}
