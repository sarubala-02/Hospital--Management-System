package com.ehealth.controller;

import com.ehealth.service.DoctorService;
import com.ehealth.service.HospitalSettingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final DoctorService doctorService;
    private final HospitalSettingService settingService;

    public HomeController(DoctorService doctorService, HospitalSettingService settingService) {
        this.doctorService = doctorService;
        this.settingService = settingService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("hospitalName", settingService.getHospitalName());
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        model.addAttribute("doctors", doctorService.findAllAvailableDoctors());
        return "index";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("hospitalName", settingService.getHospitalName());
        return "about";
    }

    @GetMapping("/departments")
    public String departments(Model model) {
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        return "departments";
    }

    @GetMapping("/doctors")
    public String doctors(Model model) {
        model.addAttribute("doctors", doctorService.findAllAvailableDoctors());
        model.addAttribute("departments", doctorService.findAllActiveDepartments());
        return "doctors";
    }
}
