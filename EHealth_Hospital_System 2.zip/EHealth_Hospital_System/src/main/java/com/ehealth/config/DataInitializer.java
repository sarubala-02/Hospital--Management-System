package com.ehealth.config;

import com.ehealth.entity.*;
import com.ehealth.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final DoctorRepository doctorRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final PatientRepository patientRepository;
    private final AppointmentRepository appointmentRepository;
    private final ConsultationRepository consultationRepository;
    private final PrescriptionRepository prescriptionRepository;
    private final InvoiceRepository invoiceRepository;
    private final HospitalSettingRepository settingRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(RoleRepository roleRepository,
                           UserRepository userRepository,
                           DepartmentRepository departmentRepository,
                           DoctorRepository doctorRepository,
                           DoctorAvailabilityRepository availabilityRepository,
                           PatientRepository patientRepository,
                           AppointmentRepository appointmentRepository,
                           ConsultationRepository consultationRepository,
                           PrescriptionRepository prescriptionRepository,
                           InvoiceRepository invoiceRepository,
                           HospitalSettingRepository settingRepository,
                           PasswordEncoder passwordEncoder) {
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
        this.departmentRepository = departmentRepository;
        this.doctorRepository = doctorRepository;
        this.availabilityRepository = availabilityRepository;
        this.patientRepository = patientRepository;
        this.appointmentRepository = appointmentRepository;
        this.consultationRepository = consultationRepository;
        this.prescriptionRepository = prescriptionRepository;
        this.invoiceRepository = invoiceRepository;
        this.settingRepository = settingRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        log.info("Checking database initialization...");

        // 1. Initialize Roles
        Role adminRole = getOrCreateRole(RoleName.ROLE_ADMIN, "Hospital Administrator with full system governance");
        Role doctorRole = getOrCreateRole(RoleName.ROLE_DOCTOR, "Licensed Medical Doctor with clinical record access");
        Role receptionistRole = getOrCreateRole(RoleName.ROLE_RECEPTIONIST, "Front Desk Staff managing appointments and check-in");
        Role billingRole = getOrCreateRole(RoleName.ROLE_BILLING, "Financial and Billing Officer handling itemized invoices");
        Role patientRole = getOrCreateRole(RoleName.ROLE_PATIENT, "Registered Patient managing appointments and medical records");

        // 2. Initialize Settings
        initSetting("HOSPITAL_NAME", "Apex Care Multi-Speciality Hospital & Research Center", "Hospital organization name");
        initSetting("TAX_RATE_PERCENT", "5.0", "Standard service tax / GST percentage");
        initSetting("CURRENCY_CODE", "INR", "Default billing currency");
        initSetting("ALLOW_PARTIAL_PAYMENT", "true", "Permit patients to make partial installment payments");

        // 3. Initialize Departments
        Department cardio = getOrCreateDepartment("Cardiology", "CARD", "Comprehensive cardiovascular diagnostics, interventions, and surgery", "Dr. Rajesh Sharma, MD, DM");
        Department neuro = getOrCreateDepartment("Neurology", "NEUR", "Advanced neurological diagnosis, stroke management, and neuro-rehabilitation", "Dr. Ananya Iyer, MD, DM");
        Department ortho = getOrCreateDepartment("Orthopedics", "ORTH", "Joint replacements, trauma, sports medicine, and spine surgery", "Dr. Vikram Patel, MS, MCh");
        Department peds = getOrCreateDepartment("Pediatrics", "PED", "Neonatal and compassionate child healthcare", "Dr. Sunita Rao, MD, DCH");
        Department genMed = getOrCreateDepartment("General Medicine", "GENMED", "Primary adult healthcare and chronic disease management", "Dr. Arvind Menon, MD");

        // 4. Initialize Users & Profiles
        String defaultPasswordHash = passwordEncoder.encode("password123");

        // Admin User
        User admin = userRepository.findByUsername("admin").orElseGet(() -> {
            User u = new User("admin", defaultPasswordHash, "Hospital Administrator", "admin@apexcare.org", "+91 98765 00001");
            u.getRoles().add(adminRole);
            return userRepository.save(u);
        });

        // Receptionist User
        User receptionist = userRepository.findByUsername("receptionist1").orElseGet(() -> {
            User u = new User("receptionist1", defaultPasswordHash, "Pooja Verma", "pooja.verma@apexcare.org", "+91 98765 00004");
            u.getRoles().add(receptionistRole);
            return userRepository.save(u);
        });

        // Billing Staff User
        User billingUser = userRepository.findByUsername("billing1").orElseGet(() -> {
            User u = new User("billing1", defaultPasswordHash, "Karthik Nair", "karthik.nair@apexcare.org", "+91 98765 00005");
            u.getRoles().add(billingRole);
            return userRepository.save(u);
        });

        // Doctor 1: Dr. Rajesh Sharma (Cardiology)
        User docUser1 = userRepository.findByUsername("dr.rajesh").orElseGet(() -> {
            User u = new User("dr.rajesh", defaultPasswordHash, "Dr. Rajesh Sharma", "rajesh.sharma@apexcare.org", "+91 98765 00002");
            u.getRoles().add(doctorRole);
            return userRepository.save(u);
        });
        Doctor doc1 = doctorRepository.findByUser(docUser1).orElseGet(() -> {
            Doctor d = new Doctor(docUser1, cardio, "Interventional Cardiology", "MBBS, MD, DM (Cardiology), FACC",
                    "KMC-DOC-2010-8842", 15, new BigDecimal("800.00"), "OPD-101");
            return doctorRepository.save(d);
        });
        seedScheduleForDoctor(doc1);

        // Doctor 2: Dr. Ananya Iyer (Neurology)
        User docUser2 = userRepository.findByUsername("dr.ananya").orElseGet(() -> {
            User u = new User("dr.ananya", defaultPasswordHash, "Dr. Ananya Iyer", "ananya.iyer@apexcare.org", "+91 98765 00003");
            u.getRoles().add(doctorRole);
            return userRepository.save(u);
        });
        Doctor doc2 = doctorRepository.findByUser(docUser2).orElseGet(() -> {
            Doctor d = new Doctor(docUser2, neuro, "Neuro-Oncology & Stroke", "MBBS, MD, DM (Neurology)",
                    "KMC-DOC-2014-9912", 11, new BigDecimal("750.00"), "OPD-102");
            return doctorRepository.save(d);
        });
        seedScheduleForDoctor(doc2);

        // Patient User: Rahul Deshmukh
        User patientUser = userRepository.findByUsername("patient.rahul").orElseGet(() -> {
            User u = new User("patient.rahul", defaultPasswordHash, "Rahul Deshmukh", "rahul.deshmukh@gmail.com", "+91 98765 11111");
            u.getRoles().add(patientRole);
            return userRepository.save(u);
        });
        Patient patient1 = patientRepository.findByUser(patientUser).orElseGet(() -> {
            Patient p = new Patient(
                    patientUser,
                    "MRN-2026-000101",
                    LocalDate.of(1988, 6, 15),
                    "MALE",
                    "O_POSITIVE",
                    "404 Green Valley, Indiranagar, Bengaluru",
                    "Sneha Deshmukh",
                    "+91 98765 22222"
            );
            p.setAllergies("Penicillin");
            p.setChronicConditions("Mild Hypertension");
            return patientRepository.save(p);
        });

        // 5. Seed Initial Sample Appointment & Invoice (if none exists)
        if (appointmentRepository.count() == 0) {
            LocalDate today = LocalDate.now();
            Appointment apt1 = new Appointment(
                    "APT-2026-10001",
                    patient1,
                    doc1,
                    cardio,
                    today,
                    LocalTime.of(10, 0),
                    "Chest discomfort and routine cardiac checkup"
            );
            apt1.setStatus(AppointmentStatus.COMPLETED);
            appointmentRepository.save(apt1);

            // Consultation Record
            Consultation cons1 = new Consultation(
                    apt1,
                    doc1,
                    patient1,
                    "Mild retrosternal chest heaviness during exertion, BP 130/85",
                    "Stage 1 Essential Hypertension with exertional angina suspicion",
                    "ECG normal sinus rhythm. Advised 2D Echocardiogram and lipid profile test.",
                    today.plusDays(14),
                    doc1.getConsultationFee()
            );
            consultationRepository.save(cons1);

            // Prescription Record
            Prescription rx1 = new Prescription(cons1, patient1, doc1, "Low sodium diet, 30 min daily brisk walking, avoid smoking.");
            rx1.addItem(new PrescriptionItem("Telmisartan 40mg", "1 tablet", "Once daily (Morning)", "30 days", "Take after breakfast"));
            rx1.addItem(new PrescriptionItem("Aspirin 75mg", "1 tablet", "Once daily (Night)", "30 days", "Take after dinner"));
            prescriptionRepository.save(rx1);

            // Invoice for the completed appointment
            Invoice inv1 = new Invoice("INV-2026-00001", patient1, apt1, doc1, today.plusDays(7));
            inv1.setCreatedByUser(billingUser);
            inv1.setTaxRate(new BigDecimal("0.05"));
            inv1.addItem(new InvoiceItem("Doctor Consultation - Dr. Rajesh Sharma", "CONSULTATION", 1, doc1.getConsultationFee()));
            inv1.addItem(new InvoiceItem("12-Lead Electrocardiogram (ECG)", "LAB", 1, new BigDecimal("450.00")));
            inv1.addItem(new InvoiceItem("Complete Blood Count & Lipid Profile", "LAB", 1, new BigDecimal("850.00")));
            invoiceRepository.save(inv1);

            log.info("Seeded initial appointment (APT-2026-10001) and invoice (INV-2026-00001).");
        }

        log.info("E-Health Management System database initialization completed successfully.");
    }

    private Role getOrCreateRole(RoleName name, String description) {
        return roleRepository.findByName(name)
                .orElseGet(() -> roleRepository.save(new Role(name, description)));
    }

    private Department getOrCreateDepartment(String name, String code, String description, String hod) {
        return departmentRepository.findByCode(code)
                .orElseGet(() -> departmentRepository.save(new Department(name, code, description, hod)));
    }

    private void initSetting(String key, String value, String description) {
        if (settingRepository.findByKey(key).isEmpty()) {
            settingRepository.save(new HospitalSetting(key, value, description));
        }
    }

    private void seedScheduleForDoctor(Doctor doctor) {
        for (DayOfWeek day : DayOfWeek.values()) {
            if (day != DayOfWeek.SUNDAY) {
                if (availabilityRepository.findByDoctorAndDayOfWeekAndActiveTrue(doctor, day).isEmpty()) {
                    DoctorAvailability da = new DoctorAvailability(
                            doctor,
                            day,
                            LocalTime.of(9, 0),
                            LocalTime.of(17, 0),
                            30
                    );
                    availabilityRepository.save(da);
                }
            }
        }
    }
}
