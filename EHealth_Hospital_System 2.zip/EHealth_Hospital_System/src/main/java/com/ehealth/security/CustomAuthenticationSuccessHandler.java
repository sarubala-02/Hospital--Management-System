package com.ehealth.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;

@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

        for (GrantedAuthority authority : authorities) {
            String role = authority.getAuthority();
            if ("ROLE_ADMIN".equals(role)) {
                response.sendRedirect("/admin/dashboard");
                return;
            } else if ("ROLE_DOCTOR".equals(role)) {
                response.sendRedirect("/doctor/dashboard");
                return;
            } else if ("ROLE_RECEPTIONIST".equals(role)) {
                response.sendRedirect("/receptionist/dashboard");
                return;
            } else if ("ROLE_BILLING".equals(role)) {
                response.sendRedirect("/billing/dashboard");
                return;
            } else if ("ROLE_PATIENT".equals(role)) {
                response.sendRedirect("/patient/dashboard");
                return;
            }
        }

        response.sendRedirect("/");
    }
}
