/**
 * Apex Care E-Health Management System - Client Application Script
 * Signature Canvas, Dynamic Slot Lookup, and Payment Sandbox Engine
 */

document.addEventListener('DOMContentLoaded', function () {

    // 1. Dynamic Doctor Time Slot Lookup
    const doctorSelect = document.getElementById('doctorSelect');
    const dateInput = document.getElementById('appointmentDateInput');
    const slotSelect = document.getElementById('appointmentTimeSelect');
    const slotLoading = document.getElementById('slotLoading');

    function loadSlots() {
        if (!doctorSelect || !dateInput || !slotSelect) return;
        const doctorId = doctorSelect.value;
        const date = dateInput.value;

        if (!doctorId || !date) {
            slotSelect.innerHTML = '<option value="">-- Please select doctor and date first --</option>';
            return;
        }

        if (slotLoading) slotLoading.style.display = 'inline-block';
        slotSelect.innerHTML = '<option value="">Loading available slots...</option>';

        fetch(`/receptionist/api/slots?doctorId=${doctorId}&date=${date}`)
            .then(res => res.json())
            .then(slots => {
                if (slotLoading) slotLoading.style.display = 'none';
                slotSelect.innerHTML = '';
                if (!slots || slots.length === 0) {
                    slotSelect.innerHTML = '<option value="">No available slots for this date</option>';
                    return;
                }
                slotSelect.innerHTML = '<option value="">-- Select Available Time Slot --</option>';
                slots.forEach(slot => {
                    const opt = document.createElement('option');
                    // Format slot (HH:mm)
                    const timeStr = typeof slot === 'string' ? slot.substring(0, 5) : `${slot.hour}:${slot.minute}`;
                    opt.value = timeStr;
                    opt.textContent = `${timeStr} Hrs`;
                    slotSelect.appendChild(opt);
                });
            })
            .catch(err => {
                console.error('Error fetching slots:', err);
                if (slotLoading) slotLoading.style.display = 'none';
                slotSelect.innerHTML = '<option value="">Error loading slots</option>';
            });
    }

    if (doctorSelect) doctorSelect.addEventListener('change', loadSlots);
    if (dateInput) dateInput.addEventListener('change', loadSlots);

    // 2. HTML5 Canvas Signature Pad
    const canvas = document.getElementById('signatureCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let isDrawing = false;
        let hasDrawn = false;

        // Set high DPI canvas resolution
        function resizeCanvas() {
            const rect = canvas.getBoundingClientRect();
            canvas.width = rect.width * 2;
            canvas.height = rect.height * 2;
            ctx.scale(2, 2);
            ctx.lineWidth = 2.5;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.strokeStyle = '#0f4c81';
        }
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        function getPos(e) {
            const rect = canvas.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            return {
                x: clientX - rect.left,
                y: clientY - rect.top
            };
        }

        function startDraw(e) {
            e.preventDefault();
            isDrawing = true;
            const pos = getPos(e);
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y);
        }

        function draw(e) {
            if (!isDrawing) return;
            e.preventDefault();
            const pos = getPos(e);
            ctx.lineTo(pos.x, pos.y);
            ctx.stroke();
            hasDrawn = true;
        }

        function endDraw() {
            isDrawing = false;
        }

        // Mouse Events
        canvas.addEventListener('mousedown', startDraw);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', endDraw);
        canvas.addEventListener('mouseleave', endDraw);

        // Touch Events
        canvas.addEventListener('touchstart', startDraw);
        canvas.addEventListener('touchmove', draw);
        canvas.addEventListener('touchend', endDraw);

        // Clear Button
        const clearBtn = document.getElementById('clearSignatureBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                hasDrawn = false;
                const hiddenInput = document.getElementById('signatureDataUrl');
                if (hiddenInput) hiddenInput.value = '';
                const previewImg = document.getElementById('signaturePreviewImg');
                if (previewImg) previewImg.style.display = 'none';
            });
        }

        // Form Submit
        const consentForm = document.getElementById('consentForm');
        if (consentForm) {
            consentForm.addEventListener('submit', function (e) {
                if (!hasDrawn) {
                    e.preventDefault();
                    alert('Please provide your handwritten signature on the canvas before submitting.');
                    return;
                }
                const dataUrl = canvas.toDataURL('image/png');
                const hiddenInput = document.getElementById('signatureDataUrl');
                if (hiddenInput) {
                    hiddenInput.value = dataUrl;
                }
            });
        }
    }

    // 3. Mock Sandbox Payment Checkout Simulator
    const paySandboxBtn = document.getElementById('paySandboxBtn');
    if (paySandboxBtn) {
        paySandboxBtn.addEventListener('click', function () {
            const txnId = this.getAttribute('data-txn-id');
            const amount = this.getAttribute('data-amount');
            const currency = this.getAttribute('data-currency');

            const modalEl = document.getElementById('sandboxPaymentModal');
            if (modalEl && window.bootstrap) {
                const modal = new bootstrap.Modal(modalEl);
                modal.show();
            }
        });
    }

    // 4. Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 6000);
    });
});
