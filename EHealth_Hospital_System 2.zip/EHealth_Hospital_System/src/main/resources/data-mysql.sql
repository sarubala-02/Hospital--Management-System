-- =============================================================================
-- E-Health Management System - Seed Data (MySQL 8)
-- Default Password for all seed users is: password123
-- =============================================================================

USE ehealth_db;

-- 1. Insert Roles
INSERT IGNORE INTO roles (id, name, description) VALUES
(1, 'ROLE_ADMIN', 'Hospital Administrator with full system governance'),
(2, 'ROLE_DOCTOR', 'Licensed Medical Doctor with clinical record access'),
(3, 'ROLE_RECEPTIONIST', 'Front Desk Staff managing appointments and check-in'),
(4, 'ROLE_BILLING', 'Financial and Billing Officer handling itemized invoices'),
(5, 'ROLE_PATIENT', 'Registered Patient managing appointments and medical records');

-- 2. Insert Departments
INSERT IGNORE INTO departments (id, name, code, description, head_of_department, is_active) VALUES
(1, 'Cardiology', 'CARD', 'Comprehensive cardiovascular diagnostics, interventions, and surgery', 'Dr. Rajesh Sharma, MD, DM', 1),
(2, 'Neurology', 'NEUR', 'Advanced neurological diagnosis, stroke management, and neuro-rehabilitation', 'Dr. Ananya Iyer, MD, DM', 1),
(3, 'Orthopedics', 'ORTH', 'Joint replacements, trauma, sports medicine, and spine surgery', 'Dr. Vikram Patel, MS, MCh', 1),
(4, 'Pediatrics', 'PED', 'Compassionate neonatal and general child healthcare', 'Dr. Sunita Rao, MD, DCH', 1),
(5, 'General Medicine', 'GENMED', 'Primary care, chronic disease management, and internal medicine', 'Dr. Arvind Menon, MD', 1);

-- 3. Insert Users (Password: password123 -> $2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C)
-- Password can also be auto-seeded dynamically via DataInitializer.java
INSERT IGNORE INTO users (id, username, password_hash, full_name, email, phone, is_active) VALUES
(1, 'admin', '$2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C', 'Chief Administrator', 'admin@apexcare.org', '+91 98765 00001', 1),
(2, 'dr.rajesh', '$2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C', 'Dr. Rajesh Sharma', 'rajesh.sharma@apexcare.org', '+91 98765 00002', 1),
(3, 'dr.ananya', '$2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C', 'Dr. Ananya Iyer', 'ananya.iyer@apexcare.org', '+91 98765 00003', 1),
(4, 'receptionist1', '$2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C', 'Pooja Verma', 'pooja.verma@apexcare.org', '+91 98765 00004', 1),
(5, 'billing1', '$2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C', 'Karthik Nair', 'karthik.nair@apexcare.org', '+91 98765 00005', 1),
(6, 'patient.rahul', '$2a$10$wN1F9f.y94s8nEa/J3b/ceg1fC5qfUuW9z6u7d0b3T37kF84mE89C', 'Rahul Deshmukh', 'rahul.deshmukh@gmail.com', '+91 98765 11111', 1);

-- 4. Map User Roles
INSERT IGNORE INTO user_roles (user_id, role_id) VALUES
(1, 1), -- Admin -> ROLE_ADMIN
(2, 2), -- Dr. Rajesh -> ROLE_DOCTOR
(3, 2), -- Dr. Ananya -> ROLE_DOCTOR
(4, 3), -- Receptionist -> ROLE_RECEPTIONIST
(5, 4), -- Billing -> ROLE_BILLING
(6, 5); -- Rahul -> ROLE_PATIENT

-- 5. Insert Doctors Profile
INSERT IGNORE INTO doctors (id, user_id, department_id, specialization, qualification, license_number, experience_years, consultation_fee, room_number, is_available) VALUES
(1, 2, 1, 'Interventional Cardiology', 'MBBS, MD, DM (Cardiology), FACC', 'KMC-DOC-2010-8842', 15, 800.00, 'OPD-101', 1),
(2, 3, 2, 'Neuro-Oncology & Stroke', 'MBBS, MD, DM (Neurology)', 'KMC-DOC-2014-9912', 11, 750.00, 'OPD-102', 1);

-- 6. Insert Patient Profile
INSERT IGNORE INTO patients (id, user_id, medical_record_number, date_of_birth, gender, blood_group, address, emergency_contact_name, emergency_contact_phone, allergies, chronic_conditions) VALUES
(1, 6, 'MRN-2026-000101', '1988-06-15', 'MALE', 'O_POSITIVE', '404 Green Valley, Indiranagar, Bengaluru', 'Sneha Deshmukh', '+91 98765 22222', 'Penicillin', 'Mild Hypertension');

-- 7. Insert Hospital Settings
INSERT IGNORE INTO hospital_settings (setting_key, setting_value, description) VALUES
('HOSPITAL_NAME', 'Apex Care Multi-Speciality Hospital & Research Center', 'Official hospital organization name'),
('TAX_RATE_PERCENT', '5.0', 'Standard service GST/tax percentage applicable to hospital services'),
('CURRENCY_CODE', 'INR', 'Default billing currency code'),
('ALLOW_PARTIAL_PAYMENT', 'true', 'Permit patients to make partial installment payments'),
('SANDBOX_PAYMENT_ENABLED', 'true', 'Enable payment gateway sandbox simulation mode');
