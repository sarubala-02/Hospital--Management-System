package com.ehealth;

import com.ehealth.dto.AppointmentBookingDto;
import com.ehealth.entity.*;
import com.ehealth.repository.*;
import com.ehealth.service.AppointmentService;
import com.ehealth.service.AuditLogService;
import com.ehealth.service.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AppointmentServiceTest {

    @Mock
    private AppointmentRepository appointmentRepository;
    @Mock
    private DoctorRepository doctorRepository;
    @Mock
    private PatientRepository patientRepository;
    @Mock
    private DepartmentRepository departmentRepository;
    @Mock
    private DoctorAvailabilityRepository availabilityRepository;
    @Mock
    private NotificationService notificationService;
    @Mock
    private AuditLogService auditLogService;

    @InjectMocks
    private AppointmentService appointmentService;

    private Doctor testDoctor;
    private Department testDept;
    private Patient testPatient;

    @BeforeEach
    void setUp() {
        User docUser = new User("dr.test", "pass", "Dr. Test", "dr.test@apexcare.org", "+919876500001");
        testDept = new Department("Cardiology", "CARD", "Heart Care", "Dr. Lead");
        testDoctor = new Doctor(docUser, testDept, "Cardiologist", "MD", "LIC-123", 10, new BigDecimal("800.00"), "101");
        testDoctor.setId(10L);

        User patientUser = new User("pat.test", "pass", "Patient Test", "pat@example.com", "+919876500002");
        testPatient = new Patient(patientUser, "MRN-TEST-001", LocalDate.of(1990, 1, 1), "MALE", "O_POSITIVE", "Address", "Contact", "123");
        testPatient.setId(20L);
    }

    @Test
    @DisplayName("Should successfully book appointment when slot is available")
    void testBookAppointmentSuccess() {
        AppointmentBookingDto dto = new AppointmentBookingDto();
        dto.setDoctorId(10L);
        dto.setDepartmentId(1L);
        dto.setAppointmentDate(LocalDate.now().plusDays(1));
        dto.setAppointmentTime(LocalTime.of(10, 0));
        dto.setReasonForVisit("Chest checkup");

        when(doctorRepository.findById(10L)).thenReturn(Optional.of(testDoctor));
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(testDept));
        when(appointmentRepository.findConflictingSlot(eq(testDoctor), any(), any())).thenReturn(Optional.empty());
        when(appointmentRepository.save(any(Appointment.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Appointment result = appointmentService.bookAppointment(testPatient, dto);

        assertNotNull(result);
        assertEquals(AppointmentStatus.CONFIRMED, result.getStatus());
        assertEquals(testPatient, result.getPatient());
        assertEquals(testDoctor, result.getDoctor());
        verify(appointmentRepository, times(1)).save(any(Appointment.class));
    }

    @Test
    @DisplayName("Should reject booking and throw IllegalStateException when slot conflicts")
    void testBookAppointmentRejectsConflict() {
        AppointmentBookingDto dto = new AppointmentBookingDto();
        dto.setDoctorId(10L);
        dto.setDepartmentId(1L);
        dto.setAppointmentDate(LocalDate.now().plusDays(1));
        dto.setAppointmentTime(LocalTime.of(10, 0));
        dto.setReasonForVisit("Routine follow-up");

        Appointment existingAppointment = new Appointment("APT-EXISTING", testPatient, testDoctor, testDept,
                dto.getAppointmentDate(), dto.getAppointmentTime(), "Prior visit");

        when(doctorRepository.findById(10L)).thenReturn(Optional.of(testDoctor));
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(testDept));
        when(appointmentRepository.findConflictingSlot(eq(testDoctor), any(), any())).thenReturn(Optional.of(existingAppointment));

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            appointmentService.bookAppointment(testPatient, dto);
        });

        assertTrue(ex.getMessage().contains("already booked"));
        verify(appointmentRepository, never()).save(any(Appointment.class));
    }
}
