package com.ehealth;

import com.ehealth.entity.*;
import com.ehealth.repository.*;
import com.ehealth.service.AuditLogService;
import com.ehealth.service.BillingService;
import com.ehealth.service.HospitalSettingService;
import com.ehealth.service.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BillingServiceTest {

    @Mock
    private InvoiceRepository invoiceRepository;
    @Mock
    private InvoiceItemRepository invoiceItemRepository;
    @Mock
    private AppointmentRepository appointmentRepository;
    @Mock
    private ConsultationRepository consultationRepository;
    @Mock
    private PatientRepository patientRepository;
    @Mock
    private DoctorRepository doctorRepository;
    @Mock
    private HospitalSettingService settingService;
    @Mock
    private AuditLogService auditLogService;
    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private BillingService billingService;

    private Patient testPatient;
    private Doctor testDoctor;
    private Appointment testAppointment;

    @BeforeEach
    void setUp() {
        User u1 = new User("pat1", "pass", "Patient One", "pat1@test.com", "12345");
        testPatient = new Patient(u1, "MRN-100", LocalDate.of(1990, 1, 1), "MALE", "O_POSITIVE", "City", "Kin", "123");

        User u2 = new User("doc1", "pass", "Dr. Doctor", "doc1@test.com", "54321");
        Department dept = new Department("General Medicine", "GENMED", "Medicine", "Head");
        testDoctor = new Doctor(u2, dept, "Physician", "MBBS", "LIC-999", 5, new BigDecimal("500.00"), "Room 1");

        testAppointment = new Appointment("APT-2026-001", testPatient, testDoctor, dept, LocalDate.now(), null, "Consultation");
    }

    @Test
    @DisplayName("Invoice calculation accurately computes Subtotal, 5% Tax, and Balance Due")
    void testInvoiceTotalCalculation() {
        Invoice invoice = new Invoice("INV-TEST-001", testPatient, testAppointment, testDoctor, LocalDate.now().plusDays(7));
        invoice.setTaxRate(new BigDecimal("0.05"));

        // Consultation item: 500.00
        invoice.addItem(new InvoiceItem("Doctor Consultation", "CONSULTATION", 1, new BigDecimal("500.00")));
        // Lab item: 1000.00
        invoice.addItem(new InvoiceItem("Blood Panel Test", "LAB", 1, new BigDecimal("1000.00")));

        // Subtotal = 1500.00
        assertEquals(new BigDecimal("1500.00"), invoice.getSubtotal());

        // Tax = 1500 * 0.05 = 75.00
        assertEquals(new BigDecimal("75.00"), invoice.getTaxAmount());

        // Grand Total = 1575.00
        assertEquals(new BigDecimal("1575.00"), invoice.getTotalAmount());
        assertEquals(new BigDecimal("1575.00"), invoice.getBalanceAmount());
        assertEquals(InvoiceStatus.UNPAID, invoice.getStatus());

        // Simulate Partial Payment of 575.00
        invoice.setPaidAmount(new BigDecimal("575.00"));
        invoice.recalculateTotals();

        assertEquals(new BigDecimal("1000.00"), invoice.getBalanceAmount());
        assertEquals(InvoiceStatus.PARTIALLY_PAID, invoice.getStatus());

        // Settle Remaining 1000.00
        invoice.setPaidAmount(new BigDecimal("1575.00"));
        invoice.recalculateTotals();

        assertEquals(new BigDecimal("0.00"), invoice.getBalanceAmount());
        assertEquals(InvoiceStatus.PAID, invoice.getStatus());
    }

    @Test
    @DisplayName("Should generate invoice from completed appointment and forward doctor fee")
    void testGenerateInvoiceFromAppointment() {
        when(appointmentRepository.findById(1L)).thenReturn(Optional.of(testAppointment));
        when(invoiceRepository.findByAppointment(testAppointment)).thenReturn(Optional.empty());
        when(settingService.getTaxRate()).thenReturn(new BigDecimal("0.05"));
        when(settingService.getCurrency()).thenReturn("INR");
        when(invoiceRepository.save(any(Invoice.class))).thenAnswer(i -> i.getArgument(0));

        User billingStaff = new User("staff1", "pass", "Staff", "staff@test.com", "123");
        Invoice generated = billingService.generateInvoiceFromAppointment(1L, billingStaff);

        assertNotNull(generated);
        assertEquals(1, generated.getItems().size());
        assertEquals(new BigDecimal("500.00"), generated.getSubtotal());
        assertEquals(new BigDecimal("25.00"), generated.getTaxAmount()); // 500 * 0.05
        assertEquals(new BigDecimal("525.00"), generated.getTotalAmount());
        verify(invoiceRepository, times(1)).save(any(Invoice.class));
    }
}
