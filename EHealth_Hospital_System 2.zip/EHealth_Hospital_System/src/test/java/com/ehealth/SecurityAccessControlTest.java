package com.ehealth;

import com.ehealth.dto.ConsultationDto;
import com.ehealth.entity.*;
import com.ehealth.repository.AppointmentRepository;
import com.ehealth.repository.ConsultationRepository;
import com.ehealth.repository.MedicalRecordRepository;
import com.ehealth.repository.PrescriptionRepository;
import com.ehealth.service.AuditLogService;
import com.ehealth.service.ConsultationService;
import com.ehealth.service.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SecurityAccessControlTest {

    @Mock
    private ConsultationRepository consultationRepository;
    @Mock
    private PrescriptionRepository prescriptionRepository;
    @Mock
    private MedicalRecordRepository medicalRecordRepository;
    @Mock
    private AppointmentRepository appointmentRepository;
    @Mock
    private AuditLogService auditLogService;
    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private ConsultationService consultationService;

    private Doctor authorizedDoctor;
    private Doctor unauthorizedDoctor;
    private Patient patient;
    private Appointment appointment;

    @BeforeEach
    void setUp() {
        Department dept = new Department("Cardiology", "CARD", "Heart", "Dr. HOD");

        User u1 = new User("dr.auth", "pass", "Dr. Authorized", "auth@hospital.org", "111");
        authorizedDoctor = new Doctor(u1, dept, "Cardiologist", "MD", "LIC-001", 10, new BigDecimal("800.00"), "101");
        authorizedDoctor.setId(1L);

        User u2 = new User("dr.unauth", "pass", "Dr. Unauthorized", "unauth@hospital.org", "222");
        unauthorizedDoctor = new Doctor(u2, dept, "Cardiologist", "MD", "LIC-002", 5, new BigDecimal("800.00"), "102");
        unauthorizedDoctor.setId(2L);

        User patientUser = new User("patient1", "pass", "John Patient", "patient@test.com", "333");
        patient = new Patient(patientUser, "MRN-101", LocalDate.of(1985, 4, 12), "MALE", "A_POSITIVE", "City", "Kin", "444");
        patient.setId(10L);

        appointment = new Appointment("APT-2026-999", patient, authorizedDoctor, dept, LocalDate.now(), LocalTime.of(11, 0), "Checkup");
        appointment.setId(100L);
    }

    @Test
    @DisplayName("Doctor cannot record consultation for an appointment assigned to another doctor")
    void testDoctorCannotModifyAnotherDoctorsAppointment() {
        ConsultationDto dto = new ConsultationDto();
        dto.setAppointmentId(100L);
        dto.setDiagnosis("Hypertension");

        when(appointmentRepository.findById(100L)).thenReturn(Optional.of(appointment));

        // When unauthorized doctor attempts to submit consultation
        AccessDeniedException ex = assertThrows(AccessDeniedException.class, () -> {
            consultationService.saveConsultation(unauthorizedDoctor, dto);
        });

        assertTrue(ex.getMessage().contains("You are not the assigned doctor"));
        verify(consultationRepository, never()).save(any());
        verify(appointmentRepository, never()).save(any());
    }

    @Test
    @DisplayName("Authorized doctor successfully completes consultation and updates appointment status")
    void testAuthorizedDoctorCanCompleteConsultation() {
        ConsultationDto dto = new ConsultationDto();
        dto.setAppointmentId(100L);
        dto.setDiagnosis("Normal Cardiac Sinus Rhythm");
        dto.setConsultationFee(new BigDecimal("800.00"));

        when(appointmentRepository.findById(100L)).thenReturn(Optional.of(appointment));
        when(consultationRepository.findByAppointment(appointment)).thenReturn(Optional.empty());
        when(consultationRepository.save(any(Consultation.class))).thenAnswer(inv -> inv.getArgument(0));

        Consultation result = consultationService.saveConsultation(authorizedDoctor, dto);

        assertNotNull(result);
        assertEquals("Normal Cardiac Sinus Rhythm", result.getDiagnosis());
        assertEquals(AppointmentStatus.COMPLETED, appointment.getStatus());
        verify(consultationRepository, times(1)).save(any(Consultation.class));
        verify(appointmentRepository, times(1)).save(appointment);
    }
}
