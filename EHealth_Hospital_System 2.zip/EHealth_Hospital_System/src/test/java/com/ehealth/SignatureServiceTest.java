package com.ehealth;

import com.ehealth.dto.SignatureDto;
import com.ehealth.entity.ConsentRecord;
import com.ehealth.entity.Patient;
import com.ehealth.entity.SignatureRecord;
import com.ehealth.entity.User;
import com.ehealth.repository.ConsentRecordRepository;
import com.ehealth.repository.SignatureRepository;
import com.ehealth.service.AuditLogService;
import com.ehealth.service.NotificationService;
import com.ehealth.service.SignatureService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SignatureServiceTest {

    @Mock
    private SignatureRepository signatureRepository;
    @Mock
    private ConsentRecordRepository consentRecordRepository;
    @Mock
    private AuditLogService auditLogService;
    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private SignatureService signatureService;

    private Patient testPatient;

    @BeforeEach
    void setUp() {
        User u = new User("patient.test", "pass", "Jane Doe", "jane@example.com", "9876543210");
        testPatient = new Patient(u, "MRN-TEST-999", LocalDate.of(1995, 5, 20), "FEMALE", "B_POSITIVE", "Main St", "Emergency", "911");
        testPatient.setId(55L);
    }

    @Test
    @DisplayName("Should generate cryptographic SHA-256 hash and record consent record")
    void testRecordSignatureAndConsent() {
        SignatureDto dto = new SignatureDto();
        dto.setSignatureDataUrl("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==");
        dto.setConsentTitle("Informed Surgical Consent");
        dto.setConsentType("SURGERY");
        dto.setConsentText("I consent to the recommended clinical procedure.");

        when(consentRecordRepository.findByPatientAndConsentTypeAndRevokedFalse(testPatient, "SURGERY"))
                .thenReturn(Optional.empty());
        when(signatureRepository.save(any(SignatureRecord.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        when(consentRecordRepository.save(any(ConsentRecord.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        ConsentRecord result = signatureService.recordSignatureAndConsent(testPatient, dto, "192.168.1.100", "Mozilla/5.0");

        assertNotNull(result);
        assertEquals("Informed Surgical Consent", result.getConsentTitle());
        assertFalse(result.isRevoked());
        assertNotNull(result.getSignature());
        assertNotNull(result.getSignature().getSignatureHash());
        assertEquals(64, result.getSignature().getSignatureHash().length()); // SHA-256 hex string length
        verify(auditLogService, times(1)).log(eq("ELECTRONIC_CONSENT_SIGNED"), any(), any(), any(), any());
    }

    @Test
    @DisplayName("Should reject invalid signature payload missing image header")
    void testRejectInvalidSignaturePayload() {
        SignatureDto dto = new SignatureDto();
        dto.setSignatureDataUrl("plain-text-not-an-image");
        dto.setConsentTitle("General Care");
        dto.setConsentType("GENERAL_TREATMENT");

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> {
            signatureService.recordSignatureAndConsent(testPatient, dto, "127.0.0.1", "Agent");
        });

        assertTrue(ex.getMessage().contains("Invalid signature"));
        verify(signatureRepository, never()).save(any());
    }
}
