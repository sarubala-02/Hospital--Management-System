# Apex Care E-Health Management System

A production-grade, enterprise web application built using **Java 21**, **Spring Boot 3.3.x**, **Spring Security 6**, **Spring Data JPA**, **Thymeleaf**, and **Bootstrap 5**. Designed for academic demonstration, clinical workflow evaluation, and patent evaluation.

---

## 1. Technology Stack

- **Backend**: Java 21 & Spring Boot 3.3.4
- **Security & Authorization**: Spring Security 6 with role-based access control (RBAC) and CSRF protection
- **Database & ORM**: MySQL 8 / Hibernate 6 / Spring Data JPA (with embedded H2 profile for zero-configuration instant local demonstration)
- **Frontend & Templates**: HTML5, CSS3, JavaScript, Bootstrap 5, Thymeleaf 3, Bootstrap Icons
- **PDF Generation**: OpenPDF (`com.github.librepdf:openpdf`) for high-fidelity tax invoices and payment receipts
- **Electronic Signature**: HTML5 Canvas signature pad with SHA-256 cryptographic tamper-evident consent binding
- **Payment Gateway**: Sandbox simulation engine with server-side HMAC validation + offline POS/cash recording
- **Testing**: JUnit 5, Mockito, and Spring Boot Test

---

## 2. Default Seed Accounts & Credentials

The application auto-seeds the database with test accounts on first launch. All accounts share the default demonstration password:

| Role | Username | Password | Access & Responsibilities |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `password123` | Hospital governance, doctor/staff provisioning, system audit logs, reports & settings |
| **Doctor (Cardiology)** | `dr.rajesh` | `password123` | Assigned patient consultations, diagnoses, electronic prescriptions (Rx), consultation fee tariffs |
| **Doctor (Neurology)** | `dr.ananya` | `password123` | Clinical schedule, outpatient examinations, patient history |
| **Receptionist** | `receptionist1` | `password123` | Front desk arrival queue, walk-in registration, conflict-free appointment booking |
| **Billing Officer** | `billing1` | `password123` | Itemized invoice compilation, adding diagnostic charges, recording offline cash/card payments |
| **Patient** | `patient.rahul` | `password123` | Self-service booking, medical record access, online sandbox payment, electronic signature consent |

> **Quick Login Tip**: The login page (`/login`) includes one-click role buttons that automatically populate credentials for rapid evaluation.

---

## 3. Quick Start & Execution Guide

### Prerequisites
- Java 21 (or newer JDK installed and available on `PATH`)
- Apache Maven 3.8+ (or use the included Maven wrapper)
- *(Optional)* MySQL 8 running locally on port 3306

---

### Option A: Zero-Config Instant Execution (In-Memory H2 Profile)
No database installation required. Runs instantly with seed data ready:

#### On macOS / Linux:
```bash
# 1. Navigate to the project directory
cd EHealth_Hospital_System

# 2. Run with Spring Boot Maven Plugin using H2 profile
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```

#### On Windows (Command Prompt or PowerShell):
```cmd
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```

Once started, open your web browser at:
- **Application URL**: [http://localhost:8080](http://localhost:8080)
- **H2 Database Console**: [http://localhost:8080/h2-console](http://localhost:8080/h2-console) (JDBC URL: `jdbc:h2:mem:ehealth_db`, Username: `sa`, Password: *(leave blank)*)

---

### Option B: Running with MySQL 8

#### 1. Setup Database in MySQL:
Log in to your MySQL terminal and execute:
```sql
CREATE DATABASE IF NOT EXISTS ehealth_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

#### 2. Configure Environment Variables (or defaults):
You can pass database credentials as environment variables or run directly if your MySQL root password is `root`:

```bash
# macOS / Linux:
export MYSQL_HOST=localhost
export MYSQL_PORT=3306
export MYSQL_DATABASE=ehealth_db
export MYSQL_USER=root
export MYSQL_PASSWORD=your_mysql_password
mvn spring-boot:run -Dspring-boot.run.profiles=mysql

# Windows (cmd):
set MYSQL_HOST=localhost
set MYSQL_PORT=3306
set MYSQL_DATABASE=ehealth_db
set MYSQL_USER=root
set MYSQL_PASSWORD=your_mysql_password
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

Schema tables and seed data will be verified and initialized automatically on startup.

---

## 4. Running Automated Tests

To run the unit and integration test suite:

```bash
mvn test
```

### Verified Test Suites:
1. `AppointmentServiceTest`: Verifies booking validation and rejects conflicting slot bookings for the same doctor and time.
2. `BillingServiceTest`: Validates tax calculations (GST 5%), line item summing, partial payment tracking, and status transitions.
3. `SecurityAccessControlTest`: Enforces strict clinical partitioning; verifies that a doctor cannot access or modify another clinician's appointments or patient files.
4. `SignatureServiceTest`: Validates canvas signature ingestion, 64-character SHA-256 cryptographic digest computation, and consent revocation.

---

## 5. End-to-End Workflow Demonstration

To test the complete 14-step clinical workflow:

1. **Step 1 — Login as Patient**:
   - Log in as `patient.rahul` / `password123`.
   - Go to **Book Appointment** (`/patient/appointments/book`).
   - Select Department (e.g. *Cardiology*) and Doctor (e.g. *Dr. Rajesh Sharma*).
   - Pick tomorrow's date. The system dynamically queries available non-conflicting slots.
   - Pick a time slot (e.g. *11:00 Hrs*) and submit.

2. **Step 2 — Reception Check-in**:
   - Sign in as `receptionist1` / `password123`.
   - In the **Reception Dashboard** (`/receptionist/dashboard`), click **Check-in** on Rahul's appointment. Status transitions to `CHECKED_IN`.

3. **Step 3 — Doctor Consultation & Prescription**:
   - Sign in as `dr.rajesh` / `password123`.
   - In the **Doctor Dashboard** (`/doctor/dashboard`), click **Examine Patient**.
   - Review patient allergies and history.
   - Enter Symptoms, Primary Diagnosis, Examination Notes.
   - Add Prescription Items (e.g., *Atorvastatin 20mg*, once daily at night for 30 days).
   - Enter Consultation Fee (&#8377; 800.00) and click **Finalize Consultation**.
   - Appointment status updates to `COMPLETED`.

4. **Step 4 — Billing & Invoice Generation**:
   - Sign in as `billing1` / `password123`.
   - Under **Create Invoice** (`/billing/invoices/create`), choose the completed appointment.
   - Click **Generate Invoice**.
   - An itemized invoice (`INV-...`) is generated. Click **Add Charge** to append a lab test (e.g., *2D Echocardiogram* @ &#8377; 1500).
   - Tax and totals are recalculated dynamically.

5. **Step 5 — Payment & Receipt**:
   - **Option 5A (Online Sandbox Payment)**:
     - Log in as `patient.rahul`.
     - Go to **Invoices & Bills** (`/patient/invoices`), open the bill, and click **Pay Now**.
     - Review the sandbox gateway order parameters and click **Pay (Sandbox)**.
     - The server cryptographically validates the transaction and issues an official receipt.
   - **Option 5B (Offline POS/Cash Payment)**:
     - Log in as `billing1`.
     - Open invoice, click **Record Payment**, choose *Cash* or *Card Terminal*, and submit.
   - Click **Download PDF** to download the professional OpenPDF invoice and payment receipt.

6. **Step 6 — Electronic Signature & Consent**:
   - As `patient.rahul`, visit **Electronic Signature** (`/patient/consent`).
   - Draw your handwritten signature on the HTML5 canvas.
   - Click **Sign & Securely Register Consent**.
   - The system computes the SHA-256 hash checksum and commits the consent record with client IP and timestamp to the permanent audit log.

7. **Step 7 — Audit Log Review**:
   - Log in as `admin` / `password123`.
   - Visit **Audit Logs** (`/admin/audit-logs`) to review the immutable trail of all patient views, consultations, billing generations, and signatures.

---

## 6. Architecture & Patent Documentation

Comprehensive technical documentation is provided in the `docs/` folder:
- [`docs/ARCHITECTURE.md`](file:///Users/thiru/Downloads/EHealth_Hospital_System/docs/ARCHITECTURE.md): Multi-layer architecture diagrams and security model.
- [`docs/API_AND_WORKFLOWS.md`](file:///Users/thiru/Downloads/EHealth_Hospital_System/docs/API_AND_WORKFLOWS.md): Detailed 14-step clinical sequence diagrams.
- [`docs/PATENT_DEMONSTRATION.md`](file:///Users/thiru/Downloads/EHealth_Hospital_System/docs/PATENT_DEMONSTRATION.md): Technical specification of the Cryptographic Electronic Signature & Consent Binding Mechanism (CV-ESCBA).
- [`docs/DATABASE_SCHEMA.md`](file:///Users/thiru/Downloads/EHealth_Hospital_System/docs/DATABASE_SCHEMA.md): Entity-Relationship Diagram (ERD) and table definitions.

---

## 7. License & Compliance Notice

This system is prepared for academic evaluation and hospital management demonstration. It complies with role-based access standards, CSRF safeguards, data minimization principles, and audit logging requirements.
