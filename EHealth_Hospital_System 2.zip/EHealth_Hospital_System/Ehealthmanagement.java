import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;

/**
 * E-Health Hospital Management System
 * Standalone Java Swing application. No third-party libraries required.
 * Local CSV files are stored in the "hospital_data" folder.
 *
 * Demo/academic use only. Not suitable for production clinical use or real patient data.
 */
public class Ehealthmanagement {
    private static final Path DATA_DIR = Paths.get("hospital_data");
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/uuuu");
    private static final Color NAVY = new Color(24, 55, 91);
    private static final Color BLUE = new Color(40, 110, 180);
    private static final Color BG = new Color(244, 247, 251);
    private static final Color GREEN = new Color(35, 135, 100);
    private static final Color RED = new Color(180, 65, 65);

    private final JFrame frame = new JFrame("E-Health Hospital Management System");
    private final JTabbedPane tabs = new JTabbedPane();
    private final Map<String, ModulePanel> modules = new LinkedHashMap<>();
    private JLabel status = new JLabel("Ready");

    private static final String[] PATIENT_FIELDS = {"Patient ID", "Full Name", "Age", "Gender", "Phone", "Address", "Blood Group"};
    private static final String[] DOCTOR_FIELDS = {"Doctor ID", "Full Name", "Specialization", "Phone", "Room", "Availability"};
    private static final String[] APPOINTMENT_FIELDS = {"Appointment ID", "Patient ID", "Patient Name", "Doctor", "Date", "Time", "Status", "Reason"};
    private static final String[] BILL_FIELDS = {"Bill ID", "Patient ID", "Patient Name", "Consultation Fee", "Other Charges", "Total", "Payment Status", "Date"};
    private static final String[] VISIT_FIELDS = {"Record ID", "Patient ID", "Patient Name", "Doctor", "Visit Date", "Symptoms", "Diagnosis", "Prescription / Notes"};

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ignored) {}
            new Ehealthmanagement().start();
        });
    }

    private void start() {
        try { Files.createDirectories(DATA_DIR); }
        catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Cannot create data folder:\n" + ex.getMessage());
            return;
        }

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1050, 650));
        frame.setSize(1250, 760);
        frame.setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(BG);
        root.add(buildHeader(), BorderLayout.NORTH);
        root.add(buildTabs(), BorderLayout.CENTER);
        frame.setContentPane(root);
        frame.setVisible(true);
        updateStatus("Hospital system ready");
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 22, 18, 22));
        JPanel titles = new JPanel(new GridLayout(2, 1, 0, 4));
        titles.setOpaque(false);
        JLabel title = new JLabel("E-HEALTH HOSPITAL MANAGEMENT");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 23));
        JLabel subtitle = new JLabel("Patients  •  Doctors  •  Appointments  •  Medical Records  •  Billing");
        subtitle.setForeground(new Color(215, 228, 242));
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        titles.add(title);
        titles.add(subtitle);
        header.add(titles, BorderLayout.WEST);

        JButton refresh = new JButton("Refresh Dashboard");
        refresh.addActionListener(e -> refreshDashboard());
        header.add(refresh, BorderLayout.EAST);
        return header;
    }

    private JComponent buildTabs() {
        tabs.setFont(new Font("SansSerif", Font.BOLD, 13));
        tabs.addTab("Dashboard", buildDashboard());
        addModule("Patients", "patients.csv", PATIENT_FIELDS, new String[]{"Patient ID"}, patientForm());
        addModule("Doctors", "doctors.csv", DOCTOR_FIELDS, new String[]{"Doctor ID"}, doctorForm());
        addModule("Appointments", "appointments.csv", APPOINTMENT_FIELDS, new String[]{"Appointment ID"}, appointmentForm());
        addModule("Medical Records", "medical_records.csv", VISIT_FIELDS, new String[]{"Record ID"}, recordForm());
        addModule("Billing", "billing.csv", BILL_FIELDS, new String[]{"Bill ID"}, billingForm());
        tabs.addChangeListener(e -> refreshDashboard());
        return tabs;
    }

    private JPanel buildDashboard() {
        JPanel page = new JPanel(new BorderLayout(16, 16));
        page.setBackground(BG);
        page.setBorder(new EmptyBorder(22, 22, 22, 22));

        JLabel welcome = new JLabel("Hospital Overview");
        welcome.setFont(new Font("SansSerif", Font.BOLD, 25));
        welcome.setForeground(NAVY);
        JLabel note = new JLabel("Quick view of locally saved hospital data");
        note.setForeground(new Color(90, 102, 115));
        JPanel intro = new JPanel(new GridLayout(2, 1, 0, 5));
        intro.setOpaque(false);
        intro.add(welcome);
        intro.add(note);

        JPanel cards = new JPanel(new GridLayout(2, 3, 14, 14));
        cards.setOpaque(false);
        cards.add(metricCard("Registered Patients", String.valueOf(countRows("patients.csv")), new Color(45, 115, 180)));
        cards.add(metricCard("Doctors", String.valueOf(countRows("doctors.csv")), new Color(35, 135, 100)));
        cards.add(metricCard("Appointments", String.valueOf(countRows("appointments.csv")), new Color(135, 90, 175)));
        cards.add(metricCard("Medical Records", String.valueOf(countRows("medical_records.csv")), new Color(190, 125, 40)));
        cards.add(metricCard("Bills Created", String.valueOf(countRows("billing.csv")), new Color(180, 75, 75)));
        cards.add(metricCard("Data Storage", "Local CSV", new Color(80, 100, 120)));

        JPanel top = new JPanel(new BorderLayout(0, 8));
        top.setOpaque(false);
        top.add(intro, BorderLayout.NORTH);
        top.add(cards, BorderLayout.CENTER);
        page.add(top, BorderLayout.NORTH);
        return page;
    }

    private JPanel metricCard(String label, String value, Color accent) {
        JPanel card = new JPanel(new BorderLayout(6, 12));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 5, 0, 0, accent),
                new EmptyBorder(18, 18, 18, 18)));
        JLabel name = new JLabel(label);
        name.setForeground(new Color(90, 102, 115));
        name.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JLabel val = new JLabel(value);
        val.setForeground(NAVY);
        val.setFont(new Font("SansSerif", Font.BOLD, 25));
        card.add(name, BorderLayout.NORTH);
        card.add(val, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildStatus() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(232, 238, 245));
        panel.setBorder(new EmptyBorder(7, 14, 7, 14));
        status.setForeground(new Color(70, 85, 100));
        panel.add(status, BorderLayout.WEST);
        JLabel storage = new JLabel("Storage: " + DATA_DIR.toAbsolutePath());
        storage.setForeground(new Color(70, 85, 100));
        panel.add(storage, BorderLayout.EAST);
        return panel;
    }

    private void addModule(String title, String filename, String[] columns, String[] keyFields, FormSpec formSpec) {
        ModulePanel panel = new ModulePanel(title, filename, columns, keyFields, formSpec);
        modules.put(title, panel);
        tabs.addTab(title, panel);
    }

    private FormSpec patientForm() {
        return new FormSpec(new String[]{"Full Name", "Age", "Gender", "Phone", "Address", "Blood Group"},
                new String[][]{
                        {"Full Name"}, {"Age"}, {"Gender", "Male", "Female", "Other", "Prefer not to say"},
                        {"Phone"}, {"Address"}, {"Blood Group", "Unknown", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"}
                }, 1);
    }

    private FormSpec doctorForm() {
        return new FormSpec(new String[]{"Full Name", "Specialization", "Phone", "Room", "Availability"},
                new String[][]{
                        {"Full Name"}, {"Specialization", "General Physician", "Cardiologist", "Neurologist", "Orthopedic", "Ophthalmologist", "Dentist", "Pediatrician", "Dermatologist", "Other"},
                        {"Phone"}, {"Room"}, {"Availability", "Available", "Unavailable", "On Leave"}
                }, 1);
    }

    private FormSpec appointmentForm() {
        return new FormSpec(new String[]{"Patient ID", "Doctor", "Date", "Time", "Status", "Reason"},
                new String[][]{
                        {"Patient ID"}, {"Doctor"}, {"Date"}, {"Time"}, {"Status", "Scheduled", "Completed", "Cancelled", "No-show"}, {"Reason"}
                }, 1);
    }

    private FormSpec recordForm() {
        return new FormSpec(new String[]{"Patient ID", "Doctor", "Visit Date", "Symptoms", "Diagnosis", "Prescription / Notes"},
                new String[][]{
                        {"Patient ID"}, {"Doctor"}, {"Visit Date"}, {"Symptoms"}, {"Diagnosis"}, {"Prescription / Notes"}
                }, 1);
    }

    private FormSpec billingForm() {
        return new FormSpec(new String[]{"Patient ID", "Consultation Fee", "Other Charges", "Payment Status", "Date"},
                new String[][]{
                        {"Patient ID"}, {"Consultation Fee"}, {"Other Charges"}, {"Payment Status", "Pending", "Paid", "Partially Paid"}, {"Date"}
                }, 1);
    }

    private void refreshDashboard() {
        if (tabs.getTabCount() > 0 && tabs.getComponentAt(0) instanceof JPanel) {
            tabs.setComponentAt(0, buildDashboard());
        }
        for (ModulePanel module : modules.values()) module.reload();
    }

    private int countRows(String filename) {
        Path path = DATA_DIR.resolve(filename);
        if (!Files.exists(path)) return 0;
        try (BufferedReader r = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            int count = 0;
            while (r.readLine() != null) count++;
            return count;
        } catch (IOException e) { return 0; }
    }

    private void updateStatus(String text) { status.setText(text); }

    private final class ModulePanel extends JPanel {
        private final String title, filename;
        private final String[] columns, keyFields;
        private final FormSpec spec;
        private final DefaultTableModel model;
        private final JTable table;
        private final JTextField search = new JTextField(18);
        private final LinkedHashMap<String, JComponent> fields = new LinkedHashMap<>();
        private final String[] idOptions;
        private int selectedModelRow = -1;

        ModulePanel(String title, String filename, String[] columns, String[] keyFields, FormSpec spec) {
            super(new BorderLayout(12, 12));
            this.title = title;
            this.filename = filename;
            this.columns = columns;
            this.keyFields = keyFields;
            this.spec = spec;
            this.idOptions = new String[0];
            this.model = new DefaultTableModel(columns, 0) {
                @Override public boolean isCellEditable(int row, int col) { return false; }
            };
            this.table = new JTable(model);
            setBackground(BG);
            setBorder(new EmptyBorder(16, 16, 16, 16));
            add(buildFormPanel(), BorderLayout.WEST);
            add(buildTablePanel(), BorderLayout.CENTER);
            load();
            table.getSelectionModel().addListSelectionListener(e -> {
                if (e.getValueIsAdjusting()) return;
                int view = table.getSelectedRow();
                if (view >= 0) {
                    selectedModelRow = table.convertRowIndexToModel(view);
                    populateForm(selectedModelRow);
                }
            });
        }

        private JPanel buildFormPanel() {
            JPanel panel = new JPanel(new GridBagLayout());
            panel.setBackground(Color.WHITE);
            panel.setPreferredSize(new Dimension(285, 0));
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(222, 229, 237)),
                    new EmptyBorder(14, 14, 14, 14)));
            GridBagConstraints c = new GridBagConstraints();
            c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
            c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1;
            c.insets = new Insets(0, 0, 14, 0);
            JLabel heading = new JLabel(title + " Details");
            heading.setFont(new Font("SansSerif", Font.BOLD, 17));
            heading.setForeground(NAVY);
            panel.add(heading, c);

            for (int i = 0; i < spec.labels.length; i++) {
                String label = spec.labels[i];
                c.gridy++; c.insets = new Insets(0, 0, 4, 0);
                JLabel l = new JLabel(label);
                l.setForeground(new Color(65, 75, 85));
                panel.add(l, c);
                c.gridy++; c.insets = new Insets(0, 0, 8, 0);
                JComponent field = createField(label, i);
                field.setPreferredSize(new Dimension(245, 28));
                fields.put(label, field);
                panel.add(field, c);
            }
            JButton add = button("Add", GREEN);
            JButton update = button("Update Selected", BLUE);
            JButton delete = button("Delete Selected", RED);
            JButton clear = button("Clear Form", new Color(95, 105, 118));
            c.gridy++; c.insets = new Insets(8, 0, 5, 0);
            panel.add(add, c);
            c.gridy++; c.insets = new Insets(0, 0, 5, 0);
            panel.add(update, c);
            c.gridy++;
            panel.add(delete, c);
            c.gridy++;
            c.insets = new Insets(0, 0, 0, 0);
            panel.add(clear, c);

            add.addActionListener(e -> addRecord());
            update.addActionListener(e -> updateRecord());
            delete.addActionListener(e -> deleteRecord());
            clear.addActionListener(e -> clearForm());
            return panel;
        }

        private JComponent createField(String label, int index) {
            if (label.equals("Gender") || label.equals("Blood Group") || label.equals("Specialization")
                    || label.equals("Availability") || label.equals("Status") || label.equals("Payment Status")) {
                String[] values = spec.options[index];
                return new JComboBox<>(Arrays.copyOfRange(values, 1, values.length));
            }
            if (label.equals("Date") || label.equals("Visit Date")) {
                JTextField f = new JTextField(LocalDate.now().format(DATE_FMT));
                f.setToolTipText("DD/MM/YYYY");
                return f;
            }
            if (label.equals("Time")) return new JTextField("09:00");
            if (label.equals("Age")) return new JSpinner(new SpinnerNumberModel(0, 0, 120, 1));
            if (label.equals("Consultation Fee") || label.equals("Other Charges")) return new JTextField("0.00");
            if (label.equals("Patient ID") && !title.equals("Patients")) {
                return new JComboBox<>(patientIds());
            }
            if (label.equals("Doctor") && !title.equals("Doctors")) {
                return new JComboBox<>(doctorNames());
            }
            if (label.equals("Address") || label.equals("Symptoms") || label.equals("Diagnosis") || label.equals("Prescription / Notes") || label.equals("Reason")) {
                return new JTextField();
            }
            return new JTextField();
        }

        private JPanel buildTablePanel() {
            JPanel panel = new JPanel(new BorderLayout(8, 8));
            panel.setOpaque(false);
            JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            tools.setOpaque(false);
            tools.add(new JLabel("Search:"));
            tools.add(search);
            JButton clearSearch = new JButton("Clear");
            clearSearch.addActionListener(e -> search.setText(""));
            JButton reload = new JButton("Reload");
            reload.addActionListener(e -> reload());
            JButton export = new JButton("Export CSV");
            export.addActionListener(e -> exportCsv());
            tools.add(clearSearch); tools.add(reload); tools.add(export);
            panel.add(tools, BorderLayout.NORTH);

            table.setRowHeight(27);
            table.setFont(new Font("SansSerif", Font.PLAIN, 12));
            table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            table.getTableHeader().setReorderingAllowed(false);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            table.setAutoCreateRowSorter(true);
            panel.add(new JScrollPane(table), BorderLayout.CENTER);

            search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                private void filter() {
                    String q = search.getText().trim();
                    javax.swing.RowFilter<DefaultTableModel, Integer> filter = q.isEmpty() ? null :
                            javax.swing.RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q));
                    @SuppressWarnings("unchecked")
                    javax.swing.table.TableRowSorter<DefaultTableModel> sorter =
                            (javax.swing.table.TableRowSorter<DefaultTableModel>) table.getRowSorter();
                    sorter.setRowFilter(filter);
                }
                public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
                public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
                public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            });
            return panel;
        }

        private String[] patientIds() {
            List<String> ids = new ArrayList<>();
            Path p = DATA_DIR.resolve("patients.csv");
            if (Files.exists(p)) {
                try (BufferedReader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        List<String> v = parseCsv(line);
                        if (!v.isEmpty() && !v.get(0).trim().isEmpty()) ids.add(v.get(0));
                    }
                } catch (IOException ignored) {}
            }
            if (ids.isEmpty()) ids.add("Add a patient first");
            return ids.toArray(new String[0]);
        }

        private String[] doctorNames() {
            List<String> names = new ArrayList<>();
            Path p = DATA_DIR.resolve("doctors.csv");
            if (Files.exists(p)) {
                try (BufferedReader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        List<String> v = parseCsv(line);
                        if (v.size() > 1 && !v.get(1).trim().isEmpty()) names.add(v.get(1));
                    }
                } catch (IOException ignored) {}
            }
            if (names.isEmpty()) names.add("Add a doctor first");
            return names.toArray(new String[0]);
        }

        private void addRecord() {
            String[] values = readForm();
            if (values == null) return;
            String id = makeId();
            List<String> row = new ArrayList<>();
            row.add(id);
            if (title.equals("Patients")) {
                row.add(values[0]); row.add(values[1]); row.add(values[2]); row.add(values[3]); row.add(values[4]); row.add(values[5]);
            } else if (title.equals("Doctors")) {
                row.add(values[0]); row.add(values[1]); row.add(values[2]); row.add(values[3]); row.add(values[4]);
            } else if (title.equals("Appointments")) {
                String patientName = findPatientName(values[0]);
                row.add(values[0]); row.add(patientName); row.add(values[1]); row.add(values[2]); row.add(values[3]); row.add(values[4]); row.add(values[5]);
            } else if (title.equals("Medical Records")) {
                row.add(values[0]); row.add(findPatientName(values[0])); row.add(values[1]); row.add(values[2]); row.add(values[3]); row.add(values[4]); row.add(values[5]);
            } else if (title.equals("Billing")) {
                double consult = parseMoney(values[1]), other = parseMoney(values[2]);
                row.add(values[0]); row.add(findPatientName(values[0])); row.add(String.format(Locale.US, "%.2f", consult));
                row.add(String.format(Locale.US, "%.2f", other)); row.add(String.format(Locale.US, "%.2f", consult + other));
                row.add(values[3]); row.add(values[4]);
            }
            if (isDuplicate(row, null)) {
                JOptionPane.showMessageDialog(frame, duplicateMessage(), "Duplicate record", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (!saveNewRow(row)) return;
            updateStatus(title + " record added");
            clearForm();
            refreshDashboardOnly();
        }

        private String duplicateMessage() {
            switch (title) {
                case "Patients": return "A patient with the same phone number or matching details already exists. Check the Patients list before adding.";
                case "Doctors": return "A doctor with the same phone number or matching details already exists. Check the Doctors list before adding.";
                case "Appointments": return "This patient already has an appointment with this doctor at the same date and time.";
                case "Medical Records": return "A matching medical record already exists for this patient and visit. Check Medical Records before adding.";
                case "Billing": return "An identical bill already exists for this patient. Check Billing before adding it again.";
                default: return "This record already exists.";
            }
        }

        private boolean isDuplicate(List<String> candidate, String ignoreId) {
            for (int r = 0; r < model.getRowCount(); r++) {
                String existingId = String.valueOf(model.getValueAt(r, 0));
                if (ignoreId != null && ignoreId.equals(existingId)) continue;
                List<String> existing = new ArrayList<>();
                for (int c = 0; c < model.getColumnCount(); c++) {
                    existing.add(String.valueOf(model.getValueAt(r, c)));
                }
                if (sameIdentity(candidate, existing)) return true;
            }
            return false;
        }

        private boolean sameIdentity(List<String> a, List<String> b) {
            if (title.equals("Patients")) {
                // Phone is the strongest patient identifier; also catch an exact duplicate if phone is not unique/entered.
                boolean samePhone = !a.get(4).trim().isEmpty() && normalize(a.get(4)).equals(normalize(b.get(4)));
                boolean sameDetails = sameAt(a, b, 1, 2, 3, 4, 5, 6);
                return samePhone || sameDetails;
            }
            if (title.equals("Doctors")) {
                boolean samePhone = !a.get(3).trim().isEmpty() && normalize(a.get(3)).equals(normalize(b.get(3)));
                boolean sameDetails = sameAt(a, b, 1, 2, 3, 4, 5);
                return samePhone || sameDetails;
            }
            if (title.equals("Appointments")) return sameAt(a, b, 1, 3, 4, 5);
            if (title.equals("Medical Records")) return sameAt(a, b, 1, 3, 4, 5, 6, 7);
            if (title.equals("Billing")) return sameAt(a, b, 1, 3, 4, 5, 6, 7);
            return false;
        }

        private boolean sameAt(List<String> a, List<String> b, int... indexes) {
            for (int index : indexes) {
                if (index >= a.size() || index >= b.size() || !normalize(a.get(index)).equals(normalize(b.get(index)))) return false;
            }
            return true;
        }

        private String normalize(String value) {
            return value == null ? "" : value.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        }

        private String[] readForm() {
            String[] values = new String[spec.labels.length];
            for (int i = 0; i < spec.labels.length; i++) {
                JComponent comp = fields.get(spec.labels[i]);
                values[i] = comp instanceof JComboBox ? String.valueOf(((JComboBox<?>) comp).getSelectedItem())
                        : comp instanceof JSpinner ? String.valueOf(((JSpinner) comp).getValue())
                        : ((JTextField) comp).getText().trim();
                if (values[i].isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter " + spec.labels[i] + ".", "Missing field", JOptionPane.ERROR_MESSAGE);
                    return null;
                }
            }
            if (title.equals("Appointments") || title.equals("Medical Records") || title.equals("Billing")) {
                String pid = values[0];
                if (pid.startsWith("Add a patient") || findPatientName(pid).equals("Unknown patient")) {
                    JOptionPane.showMessageDialog(frame, "Choose a valid Patient ID. Add the patient first.", "Invalid patient", JOptionPane.ERROR_MESSAGE);
                    return null;
                }
            }
            if (title.equals("Appointments") || title.equals("Medical Records")) {
                int dateIndex = title.equals("Appointments") ? 2 : 2;
                try { LocalDate.parse(values[dateIndex], DATE_FMT); }
                catch (DateTimeParseException ex) {
                    JOptionPane.showMessageDialog(frame, "Enter a valid date as DD/MM/YYYY.", "Invalid date", JOptionPane.ERROR_MESSAGE);
                    return null;
                }
            }
            if (title.equals("Billing")) {
                try {
                    if (parseMoney(values[1]) < 0 || parseMoney(values[2]) < 0) throw new NumberFormatException();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Charges must be valid non-negative numbers.", "Invalid amount", JOptionPane.ERROR_MESSAGE);
                    return null;
                }
            }
            return values;
        }

        private void updateRecord() {
            if (selectedModelRow < 0 || selectedModelRow >= model.getRowCount()) {
                JOptionPane.showMessageDialog(frame, "Select a record in the table first.");
                return;
            }
            String[] values = readForm();
            if (values == null) return;
            String id = String.valueOf(model.getValueAt(selectedModelRow, 0));
            List<String> row = buildRow(id, values);
            if (row == null) return;
            if (isDuplicate(row, id)) {
                JOptionPane.showMessageDialog(frame, duplicateMessage(), "Duplicate record", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Object[] old = rowAt(selectedModelRow);
            for (int i = 0; i < columns.length; i++) model.setValueAt(row.get(i), selectedModelRow, i);
            if (saveAll()) {
                updateStatus(title + " record updated");
                clearForm();
                refreshDashboardOnly();
            } else {
                for (int i = 0; i < columns.length; i++) model.setValueAt(old[i], selectedModelRow, i);
            }
        }

        private List<String> buildRow(String id, String[] values) {
            List<String> row = new ArrayList<>(); row.add(id);
            if (title.equals("Patients") || title.equals("Doctors")) {
                row.addAll(Arrays.asList(values));
            } else if (title.equals("Appointments")) {
                row.add(values[0]); row.add(findPatientName(values[0])); row.add(values[1]); row.add(values[2]); row.add(values[3]); row.add(values[4]); row.add(values[5]);
            } else if (title.equals("Medical Records")) {
                row.add(values[0]); row.add(findPatientName(values[0])); row.add(values[1]); row.add(values[2]); row.add(values[3]); row.add(values[4]); row.add(values[5]);
            } else if (title.equals("Billing")) {
                double a = parseMoney(values[1]), b = parseMoney(values[2]);
                row.add(values[0]); row.add(findPatientName(values[0])); row.add(String.format(Locale.US, "%.2f", a)); row.add(String.format(Locale.US, "%.2f", b)); row.add(String.format(Locale.US, "%.2f", a+b)); row.add(values[3]); row.add(values[4]);
            }
            return row;
        }

        private void deleteRecord() {
            if (selectedModelRow < 0 || selectedModelRow >= model.getRowCount()) {
                JOptionPane.showMessageDialog(frame, "Select a record in the table first.");
                return;
            }
            int answer = JOptionPane.showConfirmDialog(frame, "Delete this " + title.toLowerCase() + " record?",
                    "Confirm delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (answer != JOptionPane.YES_OPTION) return;
            Object[] old = rowAt(selectedModelRow);
            model.removeRow(selectedModelRow);
            if (saveAll()) {
                updateStatus(title + " record deleted");
                clearForm();
                refreshDashboardOnly();
            } else {
                model.insertRow(selectedModelRow, old);
            }
        }

        private Object[] rowAt(int row) {
            Object[] out = new Object[model.getColumnCount()];
            for (int c = 0; c < out.length; c++) out[c] = model.getValueAt(row, c);
            return out;
        }

        private void populateForm(int row) {
            if (row < 0 || row >= model.getRowCount()) return;
            Map<String, String> valueByLabel = new HashMap<>();
            if (title.equals("Patients")) {
                valueByLabel.put("Full Name", str(row, 1)); valueByLabel.put("Age", str(row, 2)); valueByLabel.put("Gender", str(row, 3));
                valueByLabel.put("Phone", str(row, 4)); valueByLabel.put("Address", str(row, 5)); valueByLabel.put("Blood Group", str(row, 6));
            } else if (title.equals("Doctors")) {
                valueByLabel.put("Full Name", str(row, 1)); valueByLabel.put("Specialization", str(row, 2)); valueByLabel.put("Phone", str(row, 3));
                valueByLabel.put("Room", str(row, 4)); valueByLabel.put("Availability", str(row, 5));
            } else if (title.equals("Appointments")) {
                valueByLabel.put("Patient ID", str(row, 1)); valueByLabel.put("Doctor", str(row, 3)); valueByLabel.put("Date", str(row, 4));
                valueByLabel.put("Time", str(row, 5)); valueByLabel.put("Status", str(row, 6)); valueByLabel.put("Reason", str(row, 7));
            } else if (title.equals("Medical Records")) {
                valueByLabel.put("Patient ID", str(row, 1)); valueByLabel.put("Doctor", str(row, 3)); valueByLabel.put("Visit Date", str(row, 4));
                valueByLabel.put("Symptoms", str(row, 5)); valueByLabel.put("Diagnosis", str(row, 6)); valueByLabel.put("Prescription / Notes", str(row, 7));
            } else if (title.equals("Billing")) {
                valueByLabel.put("Patient ID", str(row, 1)); valueByLabel.put("Consultation Fee", str(row, 3)); valueByLabel.put("Other Charges", str(row, 4));
                valueByLabel.put("Payment Status", str(row, 6)); valueByLabel.put("Date", str(row, 7));
            }
            for (Map.Entry<String, String> entry : valueByLabel.entrySet()) {
                JComponent c = fields.get(entry.getKey());
                if (c instanceof JComboBox) ((JComboBox<?>) c).setSelectedItem(entry.getValue());
                else if (c instanceof JSpinner) {
                    try { ((JSpinner) c).setValue(Integer.parseInt(entry.getValue())); } catch (Exception ignored) {}
                } else if (c instanceof JTextField) ((JTextField) c).setText(entry.getValue());
            }
        }

        private String str(int row, int col) { return String.valueOf(model.getValueAt(row, col)); }

        private void clearForm() {
            selectedModelRow = -1;
            table.clearSelection();
            for (int i = 0; i < spec.labels.length; i++) {
                String label = spec.labels[i];
                JComponent c = fields.get(label);
                if (c instanceof JComboBox) {
                    JComboBox<?> box = (JComboBox<?>) c;
                    if (box.getItemCount() > 0) box.setSelectedIndex(0);
                } else if (c instanceof JSpinner) ((JSpinner) c).setValue(0);
                else if (c instanceof JTextField) {
                    JTextField tf = (JTextField) c;
                    if (label.equals("Date") || label.equals("Visit Date")) tf.setText(LocalDate.now().format(DATE_FMT));
                    else if (label.equals("Time")) tf.setText("09:00");
                    else if (label.equals("Consultation Fee") || label.equals("Other Charges")) tf.setText("0.00");
                    else tf.setText("");
                }
            }
            // Refresh dependent patient and doctor dropdowns after records are added.
            for (int i = 0; i < spec.labels.length; i++) {
                String label = spec.labels[i];
                if (label.equals("Patient ID") && fields.get(label) instanceof JComboBox) {
                    JComboBox<String> old = (JComboBox<String>) fields.get(label);
                    String[] items = patientIds(); old.setModel(new DefaultComboBoxModel<>(items));
                }
                if (label.equals("Doctor") && fields.get(label) instanceof JComboBox) {
                    JComboBox<String> old = (JComboBox<String>) fields.get(label);
                    String[] items = doctorNames(); old.setModel(new DefaultComboBoxModel<>(items));
                }
            }
        }

        private String makeId() {
            String prefix = title.equals("Patients") ? "P" : title.equals("Doctors") ? "D" :
                    title.equals("Appointments") ? "A" : title.equals("Medical Records") ? "R" : "B";
            int max = 0;
            for (int i = 0; i < model.getRowCount(); i++) {
                String id = String.valueOf(model.getValueAt(i, 0));
                try { max = Math.max(max, Integer.parseInt(id.substring(1))); } catch (Exception ignored) {}
            }
            return String.format("%s%04d", prefix, max + 1);
        }

        private boolean saveNewRow(List<String> row) {
            model.addRow(row.toArray(new Object[0]));
            boolean ok = saveAll();
            if (!ok) model.removeRow(model.getRowCount() - 1);
            return ok;
        }

        private boolean saveAll() {
            Path file = DATA_DIR.resolve(filename);
            try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                for (int r = 0; r < model.getRowCount(); r++) {
                    List<String> cells = new ArrayList<>();
                    for (int c = 0; c < model.getColumnCount(); c++) cells.add(csvEscape(String.valueOf(model.getValueAt(r, c))));
                    writer.write(String.join(",", cells)); writer.newLine();
                }
                return true;
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Could not save " + title + ":\n" + ex.getMessage(), "File error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        private void load() {
            model.setRowCount(0);
            Path file = DATA_DIR.resolve(filename);
            if (!Files.exists(file)) return;
            try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    List<String> row = parseCsv(line);
                    if (row.size() == columns.length) model.addRow(row.toArray(new Object[0]));
                }
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Could not load " + title + ":\n" + ex.getMessage());
            }
        }

        void reload() { load(); }
        private void refreshDashboardOnly() {
            if (tabs.getTabCount() > 0) tabs.setComponentAt(0, buildDashboard());
            // Update dropdowns in the other modules when patient/doctor data changes.
            for (ModulePanel m : modules.values()) {
                for (String label : m.spec.labels) {
                    if (label.equals("Patient ID") && m.fields.get(label) instanceof JComboBox) {
                        JComboBox<String> cb = (JComboBox<String>) m.fields.get(label);
                        cb.setModel(new DefaultComboBoxModel<>(patientIds()));
                    }
                    if (label.equals("Doctor") && m.fields.get(label) instanceof JComboBox) {
                        JComboBox<String> cb = (JComboBox<String>) m.fields.get(label);
                        cb.setModel(new DefaultComboBoxModel<>(doctorNames()));
                    }
                }
            }
        }

        private void exportCsv() {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Export " + title + " to CSV");
            chooser.setSelectedFile(new File(filename));
            if (chooser.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) return;
            Path dest = chooser.getSelectedFile().toPath();
            try {
                Files.copy(DATA_DIR.resolve(filename), dest, StandardCopyOption.REPLACE_EXISTING);
                JOptionPane.showMessageDialog(frame, "Export completed:\n" + dest.toAbsolutePath());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Export failed:\n" + ex.getMessage(), "Export error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private String findPatientName(String patientId) {
            Path p = DATA_DIR.resolve("patients.csv");
            if (!Files.exists(p)) return "Unknown patient";
            try (BufferedReader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                String line;
                while ((line = r.readLine()) != null) {
                    List<String> v = parseCsv(line);
                    if (v.size() > 1 && v.get(0).equals(patientId)) return v.get(1);
                }
            } catch (IOException ignored) {}
            return "Unknown patient";
        }
    }

    private static class FormSpec {
        final String[] labels;
        final String[][] options;
        final int idOffset;
        FormSpec(String[] labels, String[][] options, int idOffset) {
            this.labels = labels; this.options = options; this.idOffset = idOffset;
        }
    }

    private static JButton button(String text, Color color) {
        JButton b = new JButton(text);
        b.setBackground(color); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setPreferredSize(new Dimension(245, 32));
        return b;
    }

    private static double parseMoney(String text) {
        double v = Double.parseDouble(text.trim());
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new NumberFormatException();
        return v;
    }

    private static String csvEscape(String value) {
        if (value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r"))
            return "\"" + value.replace("\"", "\"\"") + "\"";
        return value;
    }

    private static List<String> parseCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    field.append('"'); i++;
                } else quoted = !quoted;
            } else if (ch == ',' && !quoted) {
                out.add(field.toString()); field.setLength(0);
            } else field.append(ch);
        }
        out.add(field.toString());
        return out;
    }
}
